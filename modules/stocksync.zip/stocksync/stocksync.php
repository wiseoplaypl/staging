<?php
/**
 * stocksync.php
 * File generated with module generator by SzpaQ <dev-bot>
 * This file is part od module stocksync (Stock Update Configurator)
 * @author SzpaQ
 * @copyright 2019 SzpaQ
 * @license All Rights Reserved
 * */

if (!defined('_PS_VERSION_')) {
    exit;
}


class Stocksync extends Module
{
    private $errors = array();
    public function __construct()
    {
        $this->name = 'stocksync';
        $this->tab = 'others';
        $this->version = '0.0.1';
        $this->author = 'SzpaQ';
        $this->bootstrap = true;
        parent::__construct();
        $this->displayName = $this->l('Stock Update Configurator');
        $this->description = $this->l('Configure multipliers for stock updater');
        $this->confirmUninstall = $this->l('Are you sure you want to uninstall?');
        $this->ps_versions_compliancy = array('min' => '1.6', 'max' => _PS_VERSION_);
    }
    public function install()
    {
        return !parent::install()
        || !$this->registerHook('validateOrder')
        || !$this->installTabs() ? false : true;
    }
    public function getContent()
    {
        return $this->renderFormConfiguration();
        Tools::redirectAdmin(Context::getContext()->link->getAdminLink('AdminStockSystemConfiguration'));
    }
      public function renderFormConfiguration()
    {
        $this->processConfiguration();
        $this->helper = new HelperForm();
        $this->helper->module = $this;
        $this->helper->token = Tools::getAdminTokenLite('StockSystemConfiguration');
        $this->helper->title = $this->displayName;
        $form = array();
        $form['legend'] = array('title' => $this->l('COnfiguration'));
        $form['input'] = array(
            array(
                'type' => 'html',
                'label' => '',
                'required' => false,
                'name' => '<h2>Multipliers</h2>',
            ),
            array(
                'type' => 'text',
                'label' => $this->l('WSB'),
                'required' => false,
                'name' => 'WsbMultiplier',
            ),
            array(
                'type' => 'text',
                'label' => $this->l('Halmar (normal)'),
                'required' => false,
                'name' => 'HalmarMultiplier',
            ),
            array(
                'type' => 'text',
                'label' => $this->l('Halmar V-CH'),
                'required' => false,
                'name' => 'HalmarVCHMultiplier',
            ),
            array(
                'type' => 'text',
                'label' => $this->l('BRW'),
                'required' => false,
                'name' => 'BRWMultiplier',
            ),
            array(
                'type' => 'text',
                'label' => $this->l('BRW Sofas'),
                'required' => false,
                'name' => 'BRWSofasMultiplier',
            ),
            array(
                'type' => 'text',
                'label' => $this->l('Decor'),
                'required' => false,
                'name' => 'DecorMultiplier',
            ),
            array(
                'type' => 'text',
                'label' => $this->l('Tcs'),
                'required' => false,
                'name' => 'TcsMultiplier',
            ),
            array(
                'type' => 'text',
                'label' => $this->l('LPD'),
                'required' => false,
                'name' => 'LPDMultiplier',
            ),
        /*    array(
                'type' => 'text',
                'label' => $this->l('Mezz Multiplier'),
                'required' => false,
                'name' => 'MezzMultiplier',
            ),
            array(
                'type' => 'text',
                'label' => $this->l('Mattress'),
                'required' => false,
                'name' => 'MattressMultiplier',
            ),*/
        );
        $form['submit'] = array(
            'title' => $this->l('Save'),
            'class' => 'btn btn-default pull-right',
            'name' => 'Configuration_Submit',
        );
        $this->helper->fields_value = array(
            'Multipliers' => Configuration::get('Multipliers'),
            'WsbMultiplier' => Configuration::get('WsbMultiplier'),
            'HalmarMultiplier' => Configuration::get('HalmarMultiplier'),
            'HalmarVCHMultiplier' => Configuration::get('HalmarVCHMultiplier'),
            'BRWMultiplier' => Configuration::get('BRWMultiplier'),
            'BRWSofasMultiplier' => Configuration::get('BRWSofasMultiplier'),
            'MezzMultiplier' => Configuration::get('MezzMultiplier'),
            'MattressMultiplier' => Configuration::get('MattressMultiplier'),
            'DecorMultiplier' => Configuration::get('DecorMultiplier'),
            'TcsMultiplier' => Configuration::get('TcsMultiplier'),
            'LPDMultiplier' => Configuration::get('LPDMultiplier'),
        );
        return $this->helper->generateForm(array(array('form' => $form)));
    }
    public function processConfiguration()
    {
        if (Tools::getIsset('Configuration_Submit')) {
            Configuration::updateValue(
                'WsbMultiplier',
                Tools::getValue('WsbMultiplier')
            );
            Configuration::updateValue(
                'HalmarMultiplier',
                Tools::getValue('HalmarMultiplier')
            );
            Configuration::updateValue(
                'HalmarVCHMultiplier',
                Tools::getValue('HalmarVCHMultiplier')
            );
            Configuration::updateValue(
                'BRWMultiplier',
                Tools::getValue('BRWMultiplier')
            );
            Configuration::updateValue(
                'BRWSofasMultiplier',
                Tools::getValue('BRWSofasMultiplier')
            );
            Configuration::updateValue(
                'MezzMultiplier',
                Tools::getValue('MezzMultiplier')
            );
            Configuration::updateValue(
                'MattressMultiplier',
                Tools::getValue('MattressMultiplier')
            );
            Configuration::updateValue(
                'DecorMultiplier',
                Tools::getValue('DecorMultiplier')
            );
            Configuration::updateValue(
                'TcsMultiplier',
                Tools::getValue('TcsMultiplier')
            );
            Configuration::updateValue(
                'LPDMultiplier',
                Tools::getValue('LPDMultiplier')
            );
        }
    }
    public function hookvalidateOrder($params = array())
    {
        return '';
    }
    public function installTabs()
    {
        $tabs = array(
            'AdminStockSystemConfiguration',
        );
        Db::getInstance()->execute("
            DELETE FROM ". _DB_PREFIX_ ."tab WHERE module = '". $this->name ."'
        ");
        $languages = Language::getLanguages();
        foreach ($tabs as $class_name) {
            $tab = new Tab();
            $tab -> class_name = $class_name;
            $tab -> id_parent = -1;
            $tab -> active = 1;
            $tab -> module = $this->name;
            $tab -> name = array();
            foreach ($languages as $v) {
                $tab->name[$v['id_lang']] = $class_name;
            }
            if (!$tab->save()) {
                Db::getInstance()->execute("
                    DELETE FROM ". _DB_PREFIX_ ."tab WHERE module = '". $this->name ."'
                ");
                return false;
            }
            return true;
        }
    }

}
