<?php
/**
 * PrestaChamps
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Commercial License
 * you can't distribute, modify or sell this code
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file
 * If you need help please contact leo@prestachamps.com
 *
 * @author    PrestaChamps <leo@prestachamps.com>
 * @copyright PrestaChamps
 * @license   commercial
 */

namespace PrestaChamps\WebPGenerator\Exceptions;

/**
 * Class FileErrorException
 *
 * @package PrestaChamps\WebPGenerator\Exceptions
 */
class FileErrorException extends WebPGeneratorException
{
    public $message = "File does not exists or permission is denied";
}
