<?php
/**
 * deliverytime.php
 * File generated with module generator by SzpaQ <dev-bot>
 * This file is part od module deliverytime (Delivery Time)
 * @author SzpaQ
 * @copyright 2019 SzpaQ
 * @license All Rights Reserved
 * */

if (!defined('_PS_VERSION_')) {
    exit;
}


class Deliverytime extends Module
{
    private $errors = array();
    public static $isUpdated = false;

    public function __construct()
    {
        $this->name = 'deliverytime';
        $this->tab = 'administration';
        $this->version = '0.0.1';
        $this->author = 'SzpaQ';
        $this->bootstrap = true;
        parent::__construct();
        $this->displayName = $this->l('Delivery Time');
        $this->description = $this->l('Connects supplier with delivery time. Update automatically delivery time if supplier was changed)');
        $this->confirmUninstall = $this->l('Are you sure you want to uninstall?');
        $this->ps_versions_compliancy = array('min' => '1.6', 'max' => _PS_VERSION_);
        $this->registerHook('displayEmailLine');
    }
    public function install()
    {
        return !parent::install() || !$this->registerHook('actionProductUpdate') || !$this->registerHook('displayProductButtons') ? false : true;
    }
    public function getContent()
    {
        return $this->renderFormSuplierMap();
    }
    public function hookActionProductUpdate($params = [])
    {
        $this->getDeliveryTime(new Product($params['id_product']));
    }
    public function hookDisplayProductButtons($params = [])
    {
        $product = $params['product'];
        if (is_array($product)) {
            if (isset($product['id_product'])) {
                $product = new Product((int) $product['id_product']);
            } elseif (isset($product['id'])) {
                $product = new Product((int) $product['id']);
            } elseif (isset($product['product_id'])) {
                $product = new Product((int) $product['product_id']);
            }
        }
        $product = $this->getDeliveryTime($product);
        $brand = new Manufacturer($product->id_manufacturer);
        $lang = $this->l('The delivery time for this product is ');
        return isset($params['mail_template'])
            ? '<div style="font-weight: bold" class="delivery-time-mf mt-1 text-center">'.$lang . $brand -> name .'.</div>'
            : '<div style="" class="delivery-time-mf mt-1 text-center"><small>'.$lang . '<strong>' .$brand -> name .'.</strong></small></div>';
    }
    public function hookDisplayEmailLine($params = [])
    {
        $product = new Product((int) $params['id_product']);
        $product = $this->getDeliveryTime($product);
        $brand = new Manufacturer($product->id_manufacturer);
        return '<div><small>Delivery / Collection: '. $brand -> name .'.</small></div>';
    }
    public function getDeliveryTime($product)
    {
        if (is_array($product)) {
            if (isset($product['id_product'])) {
                $product = new Product((int) $product['id_product']);
            } elseif (isset($product['id'])) {
                $product = new Product((int) $product['id']);
            } elseif (isset($product['product_id'])) {
                $product = new Product((int) $product['product_id']);
            }
        }

        $name = 'Switch_delivery_time_'. $product ->id_supplier;
        if ($id_manufacturer =  Configuration::get($name)) {
            if ($product -> id_manufacturer != $id_manufacturer) {
                $product = new Product($product->id);
                if (!$product->id) {
                    $product = new Product(Tools::getValue('id_product'));
                }
                if ($product->id) {
                    if ($product -> id_manufacturer != $id_manufacturer) {
                        $product -> id_manufacturer = (int) $id_manufacturer;
                        $product->save();
                    }
                }
            }
        }
        return $product;
    }
    public function renderFormSuplierMap()
    {
        $this->processSuplierMap();
        $this->helper = new HelperForm();
        $this->helper->module = $this;
        $this->helper->token = Tools::getAdminTokenLite('SupplierMap');
        $this->helper->title = $this->displayName;
        $form = array();
        $form['legend'] = array('title' => $this->l('SuplierMap'));
        $form['input'] = array();
        $suppliers = Db::getInstance()->executeS("select * from ". _DB_PREFIX_ ."supplier");
        $values = [];
        foreach ($suppliers as $v) {
            $name = 'Switch_delivery_time_'. $v['id_supplier'];
            $values[$name] = Configuration::get($name);
            $form['input'][] = array(
                'type' => 'select',
                'label' => $v['name'],
                'required' => false,
                'name' => $name,
                'desc' => '',
                'options' => array(
                    'query' => $this->getselectOptions(),
                    'id' => 'id',
                    'name' => 'name',
                ),
            );
        }
        $form['submit'] = array(
            'title' => $this->l('Save'),
            'class' => 'btn btn-default pull-right',
            'name' => 'SuplierMap_Submit',
        );
        $this->helper->fields_value = $values;
        return $this->helper->generateForm(array(array('form' => $form)));
    }
    public function processSuplierMap()
    {
        if (Tools::getIsset('SuplierMap_Submit')) {
            $suppliers = Db::getInstance()->executeS("select * from ". _DB_PREFIX_ ."supplier");
            foreach ($suppliers as $v) {
                $name = 'Switch_delivery_time_'. $v['id_supplier'];
                Configuration::updateValue($name, Tools::getValue($name));
            }
        }
    }
    private function getselectOptions() : array
    {
        $array = Db::getInstance()->executeS("
            SELECT id_manufacturer id, name
            FROM ". _DB_PREFIX_ ."manufacturer
        ");
        $non = [['id' => 0, 'name' => 'Nothing']];
        return array_merge($non, $array);
    }

}
