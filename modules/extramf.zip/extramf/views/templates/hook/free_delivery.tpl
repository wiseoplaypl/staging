{*
 * File generated with module files generator by SzpaQ <dev-bot>
 * @author SzpaQ
 * @copyright 2021 SzpaQ
 * @module extramf (MF extra features)
 * @version 0.0.1
 * @license All Rights Reserved
 *}


<span class="fast-delivery free-delivery">{l s='Free Delivery' mod='extramf'}</span>
