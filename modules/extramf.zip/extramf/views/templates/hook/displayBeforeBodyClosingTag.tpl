{*
 * File generated with module files generator by SzpaQ <dev-bot>
 * @author SzpaQ
 * @copyright 2021 SzpaQ
 * @module extramf (MF extra features)
 * @version 0.0.1
 * @license All Rights Reserved
 *}


<script>
    var states = {$states nofilter};
    window.addEventListener('load', function(){
        setInterval(changeCountyBasedOnPostCode, 1000);
        $('body').on('change', '#postcode', changeCountyBasedOnPostCode)
        $('body').on('keyup', '#postcode', changeCountyBasedOnPostCode)
        //loadJS("https://cdnjs.cloudflare.com/ajax/libs/waypoints/2.0.0/shortcuts/sticky-elements/waypoints-sticky.js", true);
     //   StickyHeaderInit();
    });
    var changeCountyBasedOnPostCode = function() {
        if ($('#checkout-addresses-step').length) {
            var elem = $('#postcode');
            if (typeof states[$(elem).val().substring(0,3).toLowerCase()] !== 'undefined') {
                selectedState = states[$(elem).val().substring(0,3).toLowerCase()]
                if ($("#id_state option[value='"+selectedState+"']").length > 0) {
                    $('#id_state').val(selectedState).trigger('change');
                }
            }
        }
    }
    var StickyHeaderInit = function() {
        $('#mobile-header-sticky').waypoint({
            direction:'up',
            handler: function(direction) {
                if (direction == 'down') {
                    $('#mobile-header-sticky').css('position', 'fixed').css('top', 0).css('width', '100%');
                } else {
                    $('#mobile-header-sticky').attr('style', '');
                }
                console.log(direction)
            }
        });
    }


    var DevBotPlayer = {
        init: function(){
            if (!stprovideos || !stprovideos.videos || !stprovideos.videos.length) {
                return;
            }
                return;
            $('.st_pro_video_btn').hide();
            $('.st_pro_videos_box').hide();
            for (var i = 0; i < stprovideos.videos.length; i++) {
                var url = stprovideos.videos[i].url;
                var thumbContainer = $('#product-images-thumbs .swiper-wrapper');
                var size = {
                    width: thumbContainer.find('.thumb').width(),
                    height: thumbContainer.find('.thumb').height(),
                };
                var html = '<div class="swiper-slide swiper-slide-visible" style="width: 129.2px;"> \
                    <div class="thumb-container"> \
                        <img class="thumb js-thumb img-fluid swiper-lazy swiper-lazy-loaded video-play-btn" data-image-medium-src="https://murphyfurniture.ie/93884-medium_default/pandora-4-6ft-bedframe-velvet-grey.jpg" data-image-large-src="https://murphyfurniture.ie/93884-thickbox_default/pandora-4-6ft-bedframe-velvet-grey.jpg" \
                         alt="" title="" width="452" height="584" itemprop="image" \
                             src="https://murphyfurniture.ie/img/thumb.png" \
                             style="object-fit:contain; height:'+size.height+'px; width:'+ size.width+'px" \
                             >\
                         </div>\
                    </div>';
                $('body').on('click', '.js-thumb', function(){
                    $('.st_pro_video_btn').hide();
                    $('.st_pro_videos_box').hide();
                    if ($(this).hasClass('video-play-btn')) {
                  //      $('.st_pro_video_btn').show();
                        var h = $('#product-images-large').height();
                        $('.st_pro_videos_box').eq(0).show().css(
                            'padding-top',
                            ((h - $('.st_pro_videos_box').eq(0).find('video').height()) / 2) + 'px'

                        );
                        console.log(((h - $('.st_pro_videos_box').eq(0).find('video').height()) / 2) + 'px', h, $('.st_pro_videos_box').eq(0).height())
                        $('#st_pro_video_13 video').get(0).play();
                 //       document.getElementById('video-play-js').play();
//                        console.log($('video.st_pro_videos').get(0).play());

                    }
                })
                thumbContainer.append(html);
            //    $('#thumbVideo').controls=false
            }

        }
    }
    window.addEventListener('load', function(){
        DevBotPlayer.init();
    })
</script>

<style>
    .st_pro_video_btn,
    .st_pro_videos_box{
  /*      display:none;*/
    }
</style>
