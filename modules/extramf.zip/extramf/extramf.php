<?php
/**
 * extramf.php
 * File generated with module generator by SzpaQ <dev-bot>
 * This file is part od module extramf (MF extra features)
 * @author SzpaQ
 * @copyright 2019 SzpaQ
 * @license All Rights Reserved
 * */

if (!defined('_PS_VERSION_')) {
    exit;
}


class Extramf extends Module
{
    private $errors = array();
    public function __construct()
    {
        $this->name = 'extramf';
        $this->tab = 'administration';
        $this->version = '0.0.1';
        $this->author = 'SzpaQ';
        parent::__construct();
        $this->displayName = $this->l('MF extra features');
        $this->description = $this->l('Add some features to murphyfurniture');
        $this->confirmUninstall = $this->l('Are you sure you want to uninstall?');
        $this->ps_versions_compliancy = array('min' => '1.6', 'max' => _PS_VERSION_);
        $this->registerHook('displayProductMiniatureTop');
        $this->registerHook('actionPDFInvoiceRender');
    }
    public function install()
    {
        return !parent::install() || !$this->registerHook('displayBeforeBodyClosingTag') ? false : true;
    }
    public function hookDisplayBeforeBodyClosingTag($params = array())
    {
        $this->context->smarty->assign('states', json_encode($this->getAllStates()));
        return $this->display(__FILE__, "views/templates/hook/displayBeforeBodyClosingTag.tpl");
    }
    public function getAllStates()
    {
        $states = Db::getInstance()->executeS("SELECT iso_code, id_state FROM ". _DB_PREFIX_ ."state");
        $result = [];
        foreach ($states as $v) {
            $result[strtolower($v['iso_code'])] = $v['id_state'];
        }
        return $result;
    }
    public function getDeliveryCostTranslation($translation)
    {
        if (!isset(Context::getContext()->cart) && !isset(Context::getContext()->cart->id_address_delivery)) {
            return $this->l('To be calculated');
        }
        return $translation;
    }
    public function hookDisplayCartShippingValue($params)
    {
        if (
            !isset(Context::getContext()->cart) ||
            !isset(Context::getContext()->cart->id_carrier) ||
            !Context::getContext()->cart->id_carrier
        ) {
            return $this->l('To be calculated');
        }
        return $params['current_value'];
    }
    public function hookDisplayProductMiniatureTop($params = [])
    {
        $content = '';
        if (file_exists(dirname(__FILE__) ."/views/templates/hook/displayProductMiniatureTop.tpl")) {
            $content = $this->display(__FILE__, "views/templates/hook/free_delivery.tpl");
        }
        if ($params['product']->id_supplier == 2
            || $params['product']->id_supplier == 22
            || $params['product']->id_supplier == 21
            || $params['product']->id_supplier == 9
            || $params['product']->id_supplier == 7
        ) {
            return $content.$this->display(__FILE__, "views/templates/hook/displayProductMiniatureTop.tpl");
        }
        if (Db::getInstance()->getValue("SELECT id_product FROM ". _DB_PREFIX_ ."product_supplier WHERE id_product = '". $params['product']->id ."' AND id_supplier IN(2, 22, 9, 7, 21)")) {
            return $content.$this->display(__FILE__, "views/templates/hook/displayProductMiniatureTop.tpl");
        }
        return $content;
    }
    public function getProductDeliveryTime($product, $name = '')
    {
        if (Db::getInstance()->getValue("SELECT id_product FROM ". _DB_PREFIX_ ."product_supplier WHERE id_product = '". $product['id_product'] ."' AND id_supplier IN(22)")) {
            return '1 - 3 days';
        }
        return $name;
    }
    public function changeDeliveryTime($product)
    {
        $map = [
            // SUPPLIERS
            // 1: 1-3
            // 2: 10 - 20 days
            // 3: 5 - 10 days
            // 4: 10 - 12 days
            // 5: 20 - 40 days
            // 6: 5 - 15 days
            // 7: 14 - 28 Days
            // 8: 5 - 7 days
            // 9: 15 - 25 days
            // 10: 10 - 14 days


            // MEZZ 1-3
            2 => 1,
            // WSB 5-10
            8 => 3,
            // HALMAR 10-20
            5 => 2,
            // Fitzwilliam 1-3
            7 => 1,
            // BRW Sofas 20-40
            11 => 5,
            // Limelight Beds 10-20
            12 => 2,
            // Dreamworld 5-15
            13 => 6,
            // Natural Sleep Mattresses 10-12
            10 => 4,
            // NS Ascot Divan.Headboard 10-12
            14 => 4,
            // Decor 15-25
            16 => 9,
            // NS Special Colours D/HB 14-28
            15 => 7,
            // TCS Royal Coil 5-7
            19 => 8,
            // DW Special Divan/Headboard 10-14
            20 => 10,
            // BRW 20-25
            4 => 9,
            // Gerbor 1-3
            21 => 1,
            // BRW SOFAS MEZZ 1-3
            23 => 1,
        ];
    }
    public function hookActionPDFInvoiceRender($params)
    {
        if (preg_match('/szpak/', $_SERVER['HTTP_USER_AGENT'])) {

            /**\
            header('Content-Type:application/json');
            echo var_dump($params);
            exit;
            /**/
        }
    }
}
