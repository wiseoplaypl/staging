<?php
/**
 * AdminFeaturedProductsCOnfigurationController.php
 * File generated with module generator by SzpaQ <dev-bot>
 * This file is part od module featuredproducts (Featured Products Extra)
 * @author SzpaQ
 * @copyright 2019 SzpaQ
 * @license All Rights Reserved
 * */

if (!defined('_PS_VERSION_')) {
    exit;
}
class AdminFeaturedProductsConfigurationController extends ModuleAdminController
{
    public $obj = false;
    public $adding = true;
    protected $position_identifier = 'position';
    public function __construct()
    {
        parent::__construct();
        $this->module = Module::getInstanceByName('featuredproducts');
        $this->bootstrap = true;
        $this->name = $this->l("FeaturedProductsConfiguration");
        $this->displayName = $this->l("Featured Products");
        $this->toolbar_title = $this->l("Featured Products");
        $this->obj = new FeaturedProductsNew((int) Tools::getValue('id_featured_products_new'));
        if ($this->obj->id) {
            $this->adding = false;
        }
    }
    public function initContent()
    {
        parent::initContent();
        if (Tools::getIsset('add') || Tools::getIsset('updatefeatured_products_new')) {
            $content = $this->renderFormAddFeaturedProduct();
        } else {
            $content = $this->renderListFeaturedProducts()
                .$this->renderFormSettings();
        }
        $this->context->smarty->assign(array(
            'content' => $content,
        ));
    }
    public function renderListFeaturedProducts()
    {
        $helper = new HelperList();
        $helper->shopLinkType = '';
        $helper->simple_header = false;
        $helper->no_link = false;
        $helper->identifier = 'id_featured_products_new';
        $helper->show_toolbar = false;
        $helper->module = $this->module;
        $helper->table ='featured_products_new';
        $helper->title = $this->displayName;
        $helper->token = Tools::getAdminTokenLite('AdminFeaturedProductsConfiguration');
        $page = (int) Tools::getValue('submitFilter'. $helper->table) ?: 1;
        if ($page < 1) {
            $page = 1;
        }
        $perPage = (int) Tools::getValue($helper->table .'_pagination') ?: 50;
        $limit = (($page * $perPage) - $perPage) .','. $perPage;
        $query = "
            SELECT
                id_featured_products_new,
                name,
                id_featured_products_new display_name,
                position
            FROM
                ". _DB_PREFIX_ ."featured_products_new
        ";
        $fields = array(
            'id_featured_products_new' => array(
                'title' => $this->l('#'),
                'type' => 'string',
                'orderby' => true,
                'search' => true,
            ),
            'name' => array(
                'title' => $this->l('Name'),
                'type' => 'string',
                'orderby' => true,
                'search' => true,
            ),
            'display_name' => array(
                'title' => $this->l('Display name'),
                'type' => 'string',
                'orderby' => true,
                'search' => true,
                'callback' => 'getDisplayName',
            ),
            'position' => array(
                'title' => $this->l('Position'),
                'type' => 'string',
                'orderby' => true,
                'search' => true,
            ),
        );

        $where = array();
        $order = '';
        foreach ($fields as $k => $v) {
            if ($v['search'] && Tools::getValue($helper->table.'Filter_'. $k)) {
                $where[] = $k . ' LIKE \'%'. pSQL(Tools::getValue($helper->table.'Filter_'. $k)) .'%\'';
            }
            if (Tools::getValue($helper->table.'Orderby')
                && Tools::getValue($helper->table.'Orderway')
            ) {
                $order = ' ORDER BY '.Tools::getValue($helper->table.'Orderby') .' '
                    . (Tools::getValue($helper->table.'Orderway') == 'desc' ? 'DESC' : 'ASC');
            }
        }
        if (count($where)) {
            $query .= ' WHERE '. implode(' AND ', $where);
        }
        $helper->listTotal = Db::getInstance()->getValue(
            preg_replace('/SELECT ([^FROM]*)/', "SELECT COUNT(*) ", $query)
        );
        $query .= $order . ' LIMIT '. $limit;
        $helper->currentIndex = Context::getContext()->link->getAdminLink('AdminFeaturedProductsConfiguration', false);
        $helper->actions = array('edit', 'delete');
        $helper->bootstrap = true;
        $helper->toolbar_btn['new'] = array(
            'href' => $helper->currentIndex. '&add'.
            '&token='.Tools::getAdminTokenLite('AdminFeaturedProductsConfiguration'),
            'desc' => $this->l('Add new...')
        );
        return $helper->generateList(Db::getInstance()->executeS($query), $fields);
    }
    public function renderFormAddFeaturedProduct()
    {
        $this->helper = new HelperForm();
        $this->helper->module = $this;
        $this->helper->token = Tools::getAdminTokenLite('FeaturedProductsConfiguration');
        $this->helper->title = $this->displayName;
        $form = array();
        $form['legend'] = array(
            'title' => $this->l('AddFeaturedProduct'),
        );
        $form['tabs'] = [
            'basic' => $this->l('Basic'),
            'where' => $this->l('Where to display'),
            'connections' => $this->l('Bindings'),
        ];
        $form['input'] = array(
            array(
                'type' => 'text',
                'label' => $this->l('Name'),
                'required' => true,
                'name' => 'name',
                'desc' => 'internal name',
                'tab' => 'basic',
            ),
            array(
                'type' => 'text',
                'label' => $this->l('Position'),
                'required' => true,
                'name' => 'position',
                'desc' => $this->l('Position in the list.'),
                'tab' => 'basic',
            ),
            array(
                'type' => 'text',
                'label' => $this->l('Display name'),
                'required' => true,
                'name' => 'display_name',
                'desc' => 'Customers will see this as header',
                'lang' => true,
                'tab' => 'basic',
            ),
            array(
                'type' => 'categories',
                'label' => $this->l('Categories'),
                'required' => false,
                'name' => 'id_category',
                'desc' => 'Show related products to on products pages which belong to selected category',
                'tree' => array(
                    'id' => 'categories',
                    'use_checkbox' => true,
                    'selected_categories' => $this->obj->getSelectedCategories()
                ),
                'tab' => 'where'
            ),
            array(
                'type' => 'swap',
                'label' => $this->l('Products'),
                'name' => 'id_product',
                'required' => false,
                'col' => '8',
                'search' => true,
                'options' => array(
                'query' => $this->getOptionsProducts(),
                    'id' => 'id',
                    'name' => 'name'
                ),
                'tab' => 'where',
                'size' => 20
            ),
            array(
                'type' => 'swap',
                'label' => $this->l('Products'),
                'name' => 'id_product_associated',
                'required' => false,
                'col' => '8',
                'search' => true,
                'options' => array(
                'query' => $this->getOptionsProducts(),
                    'id' => 'id',
                    'name' => 'name'
                ),
                'tab' => 'connections',
                'size' => 20
            ),
            array(
                'type' => 'swap',
                'label' => $this->l('Category'),
                'required' => false,
                'name' => 'id_category_associated',
                'desc' => 'Show products from selected categories',
                'size' => 15,
                'options' => array(
                    'query' => $this->getidcategoryOptions(),
                    'id' => 'id',
                    'name' => 'name',
                ),
                'tab' => 'connections',
            ),

        );
        if ($this->obj->id && !Tools::getValue('id_featured_products_new')) {
            $form['input'][] = array(
                    'type' => 'text',
                    'label' => $this->l('Category'),
                    'name' => 'id_featured_products_new',
                    'tab' => 'basic',
                );
        }
        /**
        header('Content-Type:application/json');
        echo json_encode($this->obj->display_name);
        exit;
        /**/
        if (preg_match('/szpak/', $_SERVER['HTTP_USER_AGENT'])) {
            /*/header('Content-Type: application/json');echo json_encode($this->obj->getSelectedCategories());exit;/**/
        }
        $form['submit'] = array(
            'title' => $this->l('Save'),
            'class' => 'btn btn-default pull-right',
            'name' => 'AddFeaturedProduct_Submit',
        );
        $this->helper->fields_value = array(
            'name' => $this->obj ? $this->obj->name : Tools::getValue('name'),
            'display_name' => $this->obj ? $this->obj->display_name : Tools::getValue('display_name'),
            'id_product' => $this->getObjectValues('id_product'),
            'id_product_associated' => $this->getObjectValues('id_product_associated'),
            'id_category_associated' => $this->getObjectValues('id_category_associated'),
            'id_category' => $this->getObjectValues('id_category'),
            'position' => $this->obj->position,
            'id_featured_products_new' => $this->obj->id,
        );
        $this->helper->default_form_language = $this->context->language->id;
        $this->helper->allow_employee_form_lang = Configuration::get('PS_BO_ALLOW_EMPLOYEE_FORM_LANG', 0);
        $this->helper->tpl_vars = array(
            'languages' => $this->context->controller->getLanguages(),
            'id_language' => $this->context->language->id,
        );
        foreach ($this->context->controller->getLanguages() as $v) {
            $this->helper->fields_value['display_name'] = $this->obj->display_name;
        }
        return $this->helper->generateForm(array(array('form' => $form)));
    }
    public function postProcess()
    {
        if (Tools::getIsset('AddFeaturedProduct_Submit')) {
            $this->processAddFeaturedProduct();
        } elseif (Tools::getIsset('deletefeatured_products_new')) {
            if ($this->obj->delete()) {
                $this->confirmations[] = $this->l('Succesfully deleted.');
                $this->obj = new FeaturedProductsNew;
            } else {
                $this->errors[] = $this->l('Something went wrong during deleting.');
            }
        }
    }
    public function processAddFeaturedProduct()
    {
        $this->obj->name = Tools::getValue('name');
        foreach (Language::getLanguages() as $k => $v) {
            $this->obj->display_name[$v['id_lang']] = Tools::getValue('display_name_'. $v['id_lang']);
        }
        $this -> obj -> id_category = Tools::getValue('id_category');
        $this -> obj -> position = Tools::getValue('position');
        if ($this->obj->save()) {
            if ($this->adding === true) {
                $this->confirmations[] = $this->l('Added Featured products rule.');
            } else {
                $this->confirmations[] = $this->l('Featured products rule updated.');
            }
            $set = $this -> obj -> addProducts(
                Tools::getValue('id_product_selected') ?: [],
                Tools::getValue('id_category') ?: [],
                Tools::getValue('id_product_associated_selected') ?: [],
                Tools::getValue('id_category_associated_selected') ?: []
            );
            if ($set === false) {
                $this->errors[] = $this->l('Something went wrong with deleting previously added categories.');
            } elseif (is_array($set)) {
                foreach ($set as $v) {
                    $this->errors[] = $this->l('Something went wrong with adding some category: ') .$v;
                }
            } else {
                if ($this->adding === true) {
                    $this->confirmations[] = $this->l('Successfully added ') .count(Tools::getValue('id_category') ?: []) . $this->l(' categories');
                } else {
                    $this->confirmations[] = $this->l('Successfully updated.');
                }
            }

            if (count($this->confirmations)) {
                Tools::redirectAdmin(Context::getContext()->link->getAdminLink('AdminFeaturedProductsConfiguration'));
            }
        }
    }
    private function getidcategoryOptions()
    {
        /** return must be an array of rows. Row must have id and name column */
        return Db::getInstance()->executeS("
            SELECT id_category id, name
            FROM ". _DB_PREFIX_."category_lang
            WHERE id_lang = ". Context::getContext()->language->id ."

        ");
    }
    private function getOptionsProducts()
    {
        /** return must be an array of rows. Row must have id and name column */
        return Db::getInstance()->executeS("
            SELECT p.id_product id, CONCAT(p.reference, ': ', pl.name) name
            FROM ". _DB_PREFIX_."product p
            LEFT JOIN ". _DB_PREFIX_."product_lang pl
            ON p.id_product = pl.id_product
            WHERE pl.id_lang = ". Context::getContext()->language->id ."
            AND p.active = 1

        ");
    }
    public function getSelectedCategories($id = false)
    {
        if (!$id) {
            return [];
        }
    }
    public function getDisplayName($id)
    {
        $f = new FeaturedProductsNew($id);
        return $f->displayName();
    }
    public function getObjectValues($type)
    {
        if (!$this->obj) {
            return [];
        }
        $result = [];
        $featuredValues = $this->obj->getFeaturedProducts();
        /*/header('Content-Type: application/json');echo json_encode($featuredValues);exit;/**/
        switch ($type) {
            case 'id_category':
            case 'id_category_associated':
            case 'id_product':
            case 'id_product_associated':
                foreach ($featuredValues as $v) {
                    $result[] = $v[$type];
                }
            break;
            case 'position':
                $result[] = $this->obj->position;
            break;
        }
        return $result;
    }
    /**
     * renderFormSettings() : string
     * @description render form Settings
     * @return String generated form
     * */
    public function renderFormSettings()
    {
        $this->processFormSettings();
        $this->helper = new HelperForm();
        $this->helper->module = $this->module;
        $this->helper->token = Tools::getAdminTokenLite('Konfiguracja');
        $this->helper->title = $this->l('Settings');
        $form = array(
            'title' => $this->l('Settings'),
            'submit' => array(
                'title' => $this->l('Save'),
                'class' => 'btn btn-default pull-right',
                'name' => 'submitSettings',
            ),
            'input' => array(
                'collapsed' => array(
                    'label' => $this->l('Collapsed'),
                    'desc' => $this->l('Collapse list of products'),
                    'name' => 'collapsed',
                    'type' => 'switch',
                    'required' => false,
                    'values' => array(
                        array(
                            'id' => 'collapsed_ON',
                            'value' => 1,
                            'label' => $this->l('Yes'),
                        ),
                        array(
                            'id' => 'collapsed_OFF',
                            'value' => 0,
                            'label' => $this->l('No'),
                        ),
                    ),
                ),
                'add_button' => array(
                    'label' => $this->l('Display as checkbox'),
                    'desc' => $this->l('Hide "Add to cart" button and add checkbox to add with product'),
                    'name' => 'add_button',
                    'type' => 'switch',
                    'required' => false,
                    'values' => array(
                        array(
                            'id' => 'add_button_ON',
                            'value' => 1,
                            'label' => $this->l('Yes'),
                        ),
                        array(
                            'id' => 'add_button_OFF',
                            'value' => 0,
                            'label' => $this->l('No'),
                        ),
                    ),
                ),
                'hide_out_of_stock' => array(
                    'label' => $this->l('Hide out of stock'),
                    'desc' => $this->l('Hide products if out of stock'),
                    'name' => 'hide_out_of_stock',
                    'type' => 'switch',
                    'required' => false,
                    'values' => array(
                        array(
                            'id' => 'hide_out_of_stock_ON',
                            'value' => 1,
                            'label' => $this->l('Yes'),
                        ),
                        array(
                            'id' => 'hide_out_of_stock_OFF',
                            'value' => 0,
                            'label' => $this->l('No'),
                        ),
                    ),
                ),
            ),
        );
        $this->helper->fields_value = $this->valuesFormSettings();
        return $this->helper->generateForm(array(array('form' => $form)));
    }
    /**
     * processFormsettings() : null
     * @description process form Settings
     * @return null
     * */
    public function processFormSettings()
    {
        /** Do somethning with your form **/
        if (Tools::getIsset("submitSettings")) {
            foreach ($this->valuesFormSettings() as $k => $v) {
                Configuration::updateValue(
                    $this->module->name.'_'. $k,
                    Tools::getValue($k)
                );
            }
        }
    }
    /**
     * valuesFormsettings() : array
     * @description return fields_values for helperform Settings
     * @return array $helperForm->field_values
     * */
    public function valuesFormSettings() : array
    {
        $values = array();
        /** @switch collapsed **/
        $values['collapsed'] = Tools::getValue('collapsed');
        /** @switch add_button **/
        $values['add_button'] = Tools::getValue('add_button');
        /** @switch hide_out_of_stock **/
        $values['hide_out_of_stock'] = Tools::getValue('hide_out_of_stock');

        foreach ($values as $k => $v) {
            $values[$k] = Configuration::get($this->module->name.'_'. $k);
        }
        return (array) $values;
    }
}
