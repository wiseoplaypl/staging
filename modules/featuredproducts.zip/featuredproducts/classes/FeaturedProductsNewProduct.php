<?php
/**
 * FeaturedProductsNewCategory.php
 * File generated with module generator by SzpaQ <dev-bot>
 * This file is part od module featuredproducts (Featured Products Extra)
 * @author SzpaQ
 * @copyright 2019 SzpaQ
 * @license All Rights Reserved
 * */

class FeaturedProductsNewProduct extends ObjectModel
{

    /** @var Integer id_featured_products_new_category */
    public $id_featured_products_new_product;

    /** @var Integer id_featured_products_new */
    public $id_featured_products_new;

    /** @var Integer id_product */
    public $id_product = 0;

    /** @var Integer id_product_associated */
    public $id_product_associated = 0;

    /** @var Integer id_category */
    public $id_category = 0;

    /** @var Integer id_category_associated */
    public $id_category_associated = 0;

    /** @var Integer id_feature TODO*/
    public $id_feature = 0;

    /**
     * @see ObjectModel::$definition
     */
    public static $definition = array(
        'fields' => array(
            'id_featured_products_new_product' => array('type' => self::TYPE_INT, 'validate' => 'isInt',),
            'id_featured_products_new' => array('type' => self::TYPE_INT, 'validate' => 'isInt', 'required' => true,),
            'id_product' => array('type' => self::TYPE_INT, 'validate' => 'isInt', 'required' => true,),
            'id_product_associated' => array('type' => self::TYPE_INT, 'validate' => 'isInt', 'required' => true,),
            'id_category' => array('type' => self::TYPE_INT, 'validate' => 'isInt', 'required' => true,),
            'id_category_associated' => array('type' => self::TYPE_INT, 'validate' => 'isInt', 'required' => true,),
         //   'id_feature' => array('type' => self::TYPE_INT, 'validate' => 'isInt', 'required' => true,),
        ),
        'table' => 'featured_products_new_product',
        'primary' => 'id_featured_products_new_product',
    );


    public function __construct($id = null, $id_lang = null)
    {
        parent::__construct($id, $id_lang);
    }
    public static function installTable()
    {
        return Db::getInstance()->execute(
            "CREATE TABLE IF NOT EXISTS "._DB_PREFIX_."featured_products_new_product (
                `id_featured_products_new_product` INT(10) AUTO_INCREMENT,
                `id_featured_products_new` INT(10) NOT NULL,
                `id_product` INT(10) NOT NULL,
                `id_product_associated` INT(10) NOT NULL,
                `id_category` INT(10) NOT NULL,
                `id_category_associated` INT(10) NOT NULL,
                PRIMARY KEY (`id_featured_products_new_product`)
            )"
        );
    }
}
