<?php
/**
 * FeaturedProductsNew.php
 * File generated with module generator by SzpaQ <dev-bot>
 * This file is part od module featuredproducts (Featured Products Extra)
 * @author SzpaQ
 * @copyright 2019 SzpaQ
 * @license All Rights Reserved
 * */

class FeaturedProductsNew extends ObjectModel
{

    /** @var Integer id_featured_products_new */
    public $id_featured_products_new;

    /** @var String name */
    public $name;

    /** @var String display_name */
    public $display_name;

    /** @var Integer id_category */
    public $id_category;

    /** @var String id_products */
    public $id_products;

    /** @var int position */
    public $position = 0;

    /** @var Date date_add */
    public $date_add;

    /**
     * @see ObjectModel::$definition
     */
    public static $definition = array(
        'fields' => array(
            'id_featured_products_new' => array('type' => self::TYPE_INT,),
            'name' => array('type' => self::TYPE_STRING, 'validate' => 'isString', 'required' => true,),
            'display_name' => array('type' => self::TYPE_STRING, 'validate' => 'isString', 'required' => true, 'lang' => true),
            'id_category' => array('type' => self::TYPE_INT,),
            'position' => array('type' => self::TYPE_INT,),
            'date_add' => array('type' => self::TYPE_DATE, 'validate' => 'isDate',),
        ),
        'table' => 'featured_products_new',
        'primary' => 'id_featured_products_new',
        'multilang' => true,

    );
    public static function installTable()
    {
        return Db::getInstance()->execute(
            "CREATE TABLE IF NOT EXISTS "._DB_PREFIX_."featured_products_new (
                `id_featured_products_new` INT(10) AUTO_INCREMENT,
                `name` VARCHAR(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
                `id_category` INT(10) NULL,
                `position` INT(10) NULL,
                `date_add`DATETIME NOT NULL,
                PRIMARY KEY (`id_featured_products_new`)
            )"
        ) && Db::getInstance()->execute(
            "CREATE TABLE IF NOT EXISTS "._DB_PREFIX_."featured_products_new_lang (
                `id_featured_products_new_lang` INT(10) AUTO_INCREMENT,
                `id_featured_products_new` INT,
                `display_name` VARCHAR(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
                `id_lang` INT(10) NULL,
                PRIMARY KEY (`id_featured_products_new_lang`)
            )"
        );
    }
    public function getSelectedCategories($objects = false)
    {
        $ids = [];
        $categories = Db::getInstance()->executeS("
            SELECT id_category FROM "._DB_PREFIX_."featured_products_new_product WHERE id_featured_products_new = ". (int) $this->id ." GROUP BY id_category
        ");
        foreach ($categories as $k => $v) {
            $ids[] = $objects === true ? new FeaturedProductsNewCategory((int) $v['id_category']) : (int) $v['id_category'];
        }
        return $ids;
    }
    public function setCategories($array = [])
    {
        if (!$this->deleteCategories()) {
            return false;
        }
        return $this->addCategories($array);
    }
    public function addCategories($array = [])
    {
        $status = [];
        foreach ($array as $v) {
            $category = new FeaturedProductsNewCategory;
            $category -> id_category = (int) $v;
            $category -> id_featured_products_new  = (int) $this->id;
            if (!$category->save()) {
                $status[$v] = false;
            }
        }
        if (!count($status)) {
            return true;
        } else {
            return $status;
        }
    }
    public function addProducts($products, $categories, $associated_products, $associated_categories)
    {
        $this->clearAssociations();
        $status = [];
        $array = [];
        foreach ($products as $id_product) {
            foreach ($associated_products as $v) {
                $product = new FeaturedProductsNewProduct;
                $product -> id_featured_products_new  = (int) $this->id;
                $product -> id_product  = (int) $id_product;
                $product -> id_product_associated  = (int) $v;
                if (!$product->save()) {
                    $status[$v] = false;
                }
            }
            foreach ($associated_categories as $v) {
                $category = new FeaturedProductsNewProduct;
                $category -> id_featured_products_new  = (int) $this->id;
                $category -> id_product  = (int) $id_product;
                $category -> id_category_associated  = (int) $v;
                if (!$category->save()) {
                    $status[$v] = false;
                }
            }
        }
        foreach ($categories as $id_category) {
            foreach ($associated_products as $v) {
                $product = new FeaturedProductsNewProduct;
                $product -> id_featured_products_new  = (int) $this->id;
                $product -> id_category  = (int) $id_category;
                $product -> id_product_associated  = (int) $v;
                if (!$product->save()) {
                    $status[$v] = false;
                }
            }
            foreach ($associated_categories as $v) {
                $category = new FeaturedProductsNewProduct;
                $category -> id_featured_products_new  = (int) $this->id;
                $category -> id_category  = (int) $id_category;
                $category -> id_category_associated  = (int) $v;
                if (!$category->save()) {
                    $status[$v] = false;
                }
            }
        }
        if (!count($status)) {
            return true;
        } else {
            return $status;
        }
    }
    public function deleteCategories()
    {
        return Db::getInstance()->execute("DELETE FROM ". _DB_PREFIX_ ."featured_products_new_category WHERE id_featured_products_new = ". (int) $this->id);
    }
    public function clearAssociations()
    {
        return Db::getInstance()->execute("
            DELETE FROM ". _DB_PREFIX_ ."featured_products_new_product
            WHERE id_featured_products_new = '". (int) $this->id ."'
        ");
    }
    public static function getByProductId($id_product = 0)
    {
        if (!$id_product) {
            return false;
        }
        $query = "
            SELECT
                id_featured_products_new
            FROM
                ". _DB_PREFIX_ ."featured_products_new_category
            WHERE
                id_category IN(
                    SELECT
                        id_category
                    FROM
                        ". _DB_PREFIX_ ."category_product
                    WHERE
                        id_product = ". (int) $id_product ."
                )
            AND
                id_featured_products_new IN (
                    SELECT
                        id_featured_products_new
                    FROM
                        ". _DB_PREFIX_ ."featured_products_new
                )
            GROUP BY id_featured_products_new
            ORDER BY
                id_featured_products_new DESC
        ";
        $id = Db::getInstance()->executeS($query);
        /** find combinations **/
        if ($id && count($id)) {
            $result = [];
            foreach ($id as $v) {
                $result[] = new FeaturedProductsNew((int) $v['id_featured_products_new']);
            }
            return $result;
        }
        return false;
    }
    public static function getAssociationsByProductId($id_product)
    {
        $categories = Db::getInstance()->executeS("
            SELECT id_category
            FROM ". _DB_PREFIX_ ."category_product
            WHERE id_product = '". $id_product ."'
        ");
        $categories = array_map(function($category) {
            return $category['id_category'];
        }, $categories);

        $result = [];
        $sql = Db::getInstance()->executeS("
            SELECT id_featured_products_new
            FROM ". _DB_PREFIX_ ."featured_products_new_product
            WHERE
                id_product = '". $id_product ."' OR
                id_category IN
                    ('". implode("', '", $categories) ."'
                )
            GROUP BY id_featured_products_new
        ");
        foreach ($sql as $v) {
            $fpn = new FeaturedProductsNew((int) $v['id_featured_products_new']);
            $result[$fpn->position.'_'. $fpn->id] = $fpn;
        }
        ksort($result);

        return $result;
    }
    public function getProductsSelected()
    {
        $products = Db::getInstance()->executeS("
            SELECT
                p.id_product
            FROM
                ". _DB_PREFIX_ ."category_product cp
            LEFT JOIN
                ". _DB_PREFIX_ ."product p
            ON
                cp.id_product = p.id_product
            WHERE
                cp.id_category = '". (int) $this->id_category ."'
            AND
                p.active = 1
            GROUP BY
                p.id_product
        ");
        $result = [];
        foreach ($products as $k => $v) {
            $product = new Product($v['id_product']);
            $image = Product::getCover($product->id);
            $product->image = Context::getContext()->link->getImageLink(
                $product->link_rewrite[Context::getContext()->language->id],
                $image['id_image'],
                'home_default'
            );
            $result[] = [
                'image' => $product->image,
                'id' => $product->id,
                'price' => $product->getPrice(),
                'url' => Context::getContext()->link->getProductLink( $product ),
                'name' => $product->name[Context::getContext()->language->id],
            ];
        }
        return $result;
    }
    public function getAssocicatedProducts()
    {
        $result = [];
        $id_categories = [];
        $id_products = [];
        $featuredProducts = $this->getFeaturedProducts();
        foreach ($featuredProducts as $v) {
            if ($v['id_category_associated']) {
                $id_categories[$v['id_category_associated']] = $v['id_category_associated'];
            }
            if ($v['id_product_associated']) {
                $id_products[$v['id_product_associated']] = $v['id_product_associated'];
            }
        }
        $id_products_from_categories = [];
        $ids = Db::getInstance()->executeS("
            SELECT id_product
            FROM ". _DB_PREFIX_ ."category_product
            WHERE id_category IN( '". implode("', '", $id_categories) ."')
        ");
        foreach ($ids as $v) {
            $id_products[$v['id_product']] = $v['id_product'];
        }
        $out_of_stock = Configuration::get('featuredproducts_hide_out_of_stock');
        foreach ($id_products as $v) {
            $product = new Product($v);
            if (!$product->active) {
                continue;
            }
            if ($out_of_stock && !StockAvailable::getQuantityAvailableByProduct($product->id)) {
                    continue;
            }

            $image = Product::getCover($product->id);
            $product->image = Context::getContext()->link->getImageLink(
                $product->link_rewrite[Context::getContext()->language->id],
                $image['id_image'],
                'home_default'
            );
            $result[] = [
                'image' => $product->image,
                'id' => $product->id,
                'price' => $product->getPrice(),
                'url' => Context::getContext()->link->getProductLink( $product ),
                'name' => $product->name[Context::getContext()->language->id],
            ];
        }
        return $result;
        /**/header('Content-Type: application/json');echo json_encode([$result]);exit;/**/
    }
    public function displayName($id_lang = null)
    {
        if ($id_lang === null || !isset($this->display_name)) {
            $id_lang = Context::getContext()->language->id;
        }
        return isset($this->display_name[$id_lang]) ? $this->display_name[$id_lang] : '';
    }
    public function getFeaturedProducts()
    {
        $array = [];
        $sql = Db::getInstance()->executeS("
            SELECT *
            FROM ". _DB_PREFIX_ ."featured_products_new_product
            WHERE id_featured_products_new = '". $this->id ."'
        ");
        return $sql;
    }
    public function delete()
    {
        return $this->clearAssociations() && parent::delete();
    }
}
