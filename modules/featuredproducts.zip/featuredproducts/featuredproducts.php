<?php
/**
 * featuredproducts.php
 * File generated with module generator by SzpaQ <dev-bot>
 * This file is part od module featuredproducts (Featured Products Extra)
 * @author SzpaQ
 * @copyright 2019 SzpaQ
 * @license All Rights Reserved
 * */

if (!defined('_PS_VERSION_')) {
    exit;
}
use PrestaShop\PrestaShop\Core\Module\WidgetInterface;
require_once dirname(__FILE__) .'/classes/FeaturedProductsNew.php';
require_once dirname(__FILE__) .'/classes/FeaturedProductsNewCategory.php';
require_once dirname(__FILE__) .'/classes/FeaturedProductsNewProduct.php';

class Featuredproducts extends Module implements WidgetInterface
{
    private $errors = array();
    public function __construct()
    {
        $this->name = 'featuredproducts';
        $this->tab = 'front_office_features';
        $this->version = '0.0.1';
        $this->bootstrap = true;
        $this->author = 'SzpaQ';
        parent::__construct();
        $this->displayName = $this->l('Featured Products Extra');
        $this->description = $this->l('New featured products');
        $this->confirmUninstall = $this->l('Are you sure you want to uninstall?');
        $this->ps_versions_compliancy = array('min' => '1.6', 'max' => _PS_VERSION_);
    }
    public function install()
    {
        return
            !$this->installModels() ||
            !parent::install() ||
            !$this->registerHook('displayExtraProducts') ||
            !$this->registerHook('header') ||
            !$this->installTabs() ? false : true;
    }
    public function getContent()
    {
        Tools::redirectAdmin(Context::getContext()->link->getAdminLink('AdminFeaturedProductsConfiguration'));
    }
    public function hookHeader()
    {
        $this->context->controller->addCSS($this->_path.'views/css/style.css', 'all'); /**/
   //     $this->context->controller->addJS($this->_path.'views/js/script.js', 'all'); /**/
    }
    public function renderWidget($hookName, array $configuration)
    {
        if (Context::getContext()->controller->php_self == 'product') {
            $this->context->smarty->assign('checkbox', Configuration::get($this->name.'_add_button'));
            $product = new Product(Tools::getValue('id_product'));
            $this->context->smarty->assign('productPrice', number_format($product->getPrice(), 2, '.', ''));
        } else {
            $this->context->smarty->assign('checkbox', Configuration::get($this->name.'_add_button'));
            $this->context->smarty->assign('productPrice', 0);
        }
        $obj = FeaturedProductsNew::getAssociationsByProductId(Tools::getValue('id_product'));
        if ($obj && count($obj)) {
            $this->context->smarty->assign('collapsed', Configuration::get($this->name.'_collapsed'));
            $this->context->smarty->assign('cart_link', $this->context->link->getPageLink('cart'));
            $this->context->smarty->assign('reassuranceProducts', $obj);
            $this->context->smarty->assign('token', Tools::getToken(false));
            $token = Tools::getToken(false);
            return $this->display(__FILE__, "views/templates/hook/displayReassurance.tpl");
        }
    }
    public function getWidgetVariables($hookName, array $configuration)
    {

    }
    private function installModels()
    {
        $models = array(
            'FeaturedProductsNew',
            'FeaturedProductsNewCategory',
            'FeaturedProductsNewProduct',
        );
        foreach ($models as $v) {
            if (!$v::installTable()) {
                return false;
            }
        }
        return true;
    }
    public function installTabs()
    {
        $tabs = array(
            'AdminFeaturedProductsConfiguration',
        );
        Db::getInstance()->execute("
            DELETE FROM ". _DB_PREFIX_ ."tab WHERE module = '". $this->name ."'
        ");
        // authorization
        $auth = Db::getInstance()->getValue("SELECT slug FROM ". _DB_PREFIX_ ."authorization_role WHERE slug LIKE '%ADMINFEATUREDPRODUCTSCONFIGURATION%'");
        if ($auth) {
            Db::getInstance()->execute("
                DELETE FROM ". _DB_PREFIX_ ."authorization_role WHERE slug LIKE '%ADMINFEATUREDPRODUCTSCONFIGURATION%'
            ");
        }
        $languages = Language::getLanguages();
        foreach ($tabs as $class_name) {
            $tab = new Tab();
            $tab -> class_name = $class_name;
            $tab -> id_parent = Db::getInstance()->getValue("
                SELECT id_parent FROM ". _DB_PREFIX_ ."tab WHERE class_name = 'AdminProducts'
            ");
            $tab -> active = 1;
            $tab -> module = $this->name;
            $tab -> name = array();
            foreach ($languages as $v) {
                $tab->name[$v['id_lang']] = $this->l('Product bindings');
            }
            if (!$tab->save()) {
                Db::getInstance()->execute("
                    DELETE FROM ". _DB_PREFIX_ ."tab WHERE module = '". $this->name ."'
                ");
                return false;
            }
            return true;
        }
    }
    public function productBelongsToSelectedCategories($id_product = null)
    {
        if ($id_product == null) {
            if (!Tools::getValue('id_product')) {
                return false;
            }
        }
         return (bool) Db::getInstance()->getValue("
            SELECT id_product
            FROM ". _DB_PREFIX_ ."category_product
            WHERE id_category IN(". implode(',', $selected) .")
            AND id_product = ". (int) $id_product ."
        ");
    }
}
