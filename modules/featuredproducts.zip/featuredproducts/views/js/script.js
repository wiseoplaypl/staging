/**
 * @author SzpaQ
 * @version 0.0.1
 * @license All Rights Reserved
  * */
var featuredProducts = {
    idProduct: null,
    products: {},
    totalPrice: 0,
    productPrice: 0,
    modalHTML: '',
    modalContainer: '.modal-body .divide-right',
    quantity: 1,
    eventResponse: null,
    linkAction: 'add-to-cart',
    modal:true,
    btnClicked: false,
    interval: false,
    add: function(id, id_product_attribute, isTogether) {
        featuredProducts.idProduct=id;
        if (!id_product_attribute) {
            id_product_attribute = 0;
        }
        $.post(
            CartLink,
            {
                id_product: featuredProducts.idProduct,
                action:'add',
                id_customization: 0,
                qty: featuredProducts.quantity,
                add: 1,
                id_product_attribute: id_product_attribute,
                token: CartToken,
                ajax: 1
            }, function(resp) {
                resp.modal = true;
                var reason = featuredProducts;
                if (!isTogether) {
                    prestashop.emit(
                        'updateCart',
                        {
                            reason: reason,
                            resp: resp
                        }
                    );
                } else {

                }
            }
        );
    },
    getTotalPrice: function(){
        featuredProducts.totalPrice = parseFloat(featuredProducts.productPrice);
        $('.checkbox-extra-product-add').each(function(){
            if ($(this).is(':checked')) {
                featuredProducts.totalPrice += parseFloat($(this).attr('data-price'));
            }
        });
        return '€'+featuredProducts.totalPrice;
    },
    addProducts: function(){
        if (Object.keys(featuredProducts.products).length > 0) {
            for (const key in featuredProducts.products) {
                this.add(key, 0, true);
                $('[data-product-id='+ key+']').prop('checked', false);
                var imgsrc = $('[data-product-id='+ key+']').closest('.extra-feature-product').find('img').attr('src');
                var price = $('[data-product-id='+ key+']').attr('data-price');
                this.modalHTML += '<div class="row extra-products-added" style="margin-top:10px;"><div class="col-md-2"><img style="max-height:30px;margin-left:20px" src="'+imgsrc+'"></div><div class="col-md-10"><small>+ '+featuredProducts.quantity+'x '+ this.products[key] +'</small><br></div></div>';
                delete this.products[key]
            }
            featuredProducts.eventResponse.stop = true;
            prestashop.emit('updateCart', featuredProducts.eventResponse);
        }
    },
    addProduct: function(){
        featuredProducts.products = {};
        $('.checkbox-extra-product-add').each(function(){
            if ($(this).is(':checked')) {
                featuredProducts.products[$(this).attr('data-product-id')] = $(this).attr('data-product-name');
                $('.current-price');
            }
        });
        $('.product-price[itemprop=price]').html(this.getTotalPrice());
        if (Object.keys(featuredProducts.products).length > 0) {
            $('.product-discount').hide();
            $('.discount-amount').hide();
        } else {
            console.log(featuredProducts.products);
            $('.product-discount').show();
            $('.discount-amount').show();
        }
    },
    init: function(){
        $('body').on('change', '.checkbox-extra-product-add', function(){
            featuredProducts.addProduct();
        });
        prestashop.on('updateCart', function(event){
            if (event.stop == true || featuredProducts.btnClicked == false) {
                return;
            }
            featuredProducts.btnClicked = false;
            featuredProducts.eventResponse = event;
            featuredProducts.addProducts();
            featuredProducts.interval = setInterval(function(){
                featuredProducts.modalUpdate();
            }, 100);
        })
        $('body').on('click', '.related-products-extra-collapse h4', function(){
            featuredProducts.collapse(this);
        });
        $('body').on('click', '.add-to-cart', function(){
            featuredProducts.quantity = $('#quantity_wanted').val();
            featuredProducts.addProduct();
            featuredProducts.btnClicked = true;
        });

    },
    modalUpdate: function(){
        if ($('.modal-body').length && $('.modal-body').is(':visible') && !$('.extra-products-added').length) {
            $(featuredProducts.modalContainer).append(featuredProducts.modalHTML);
            featuredProducts.modalHTML = '';
            clearInterval(featuredProducts.interval)
            featuredProducts.interval = false;
        }
        console.log('interval');
    },
    collapse: function(elem) {
        $(elem).closest('.related-products-extra').toggleClass('collapsed');
    }
}
