{*
 * File generated with module files generator by SzpaQ <dev-bot>
 * @author SzpaQ
 * @copyright 2020 SzpaQ
 * @module featuredproducts (Featured Products Extra)
 * @version 0.0.1
 * @license All Rights Reserved
 *}
 <style>

 </style>
{if isset($reassuranceProducts) && $reassuranceProducts|@count > 0}
    {foreach item=features from=$reassuranceProducts}
        {assign var=products value=$features->getAssocicatedProducts()}
        {if $products|@count > 0}
            <div class="related-products-extra {if $collapsed}related-products-extra-collapse{/if}">
                <h4 style="" class="featured-products-extra">
                    {$features->displayName()}{if $collapsed} <div class="toggle-related-products"><div class="toggle-related-products-over"></div></div>{/if}
                </h4>
                <div class="reasurance-overflow-h-300">
                    {foreach item=p from=$products}
                        <div class="extra-feature-product">
                            {if $checkbox == true}
                                <input type="checkbox" name="" class="pull-right checkbox-extra-product-add" data-product-id="{$p.id}" data-price="{$p.price|number_format:2}" data-product-name="{$p.name}">
                            {else}
                                <button type="button" class="add_to_cart btn btn-primary btn-sm" onclick="featuredProducts.add({$p.id});">
                                    <i class="fa fa-shopping-bag fa-fw bag-icon"></i> {l s='Add to cart' mod='featuredproducts'}
                                </button>
                            {/if}
                            <div class="features-product-row-element">
                                <a href="{$p.url}" style="display:none"><img src="{$p.image}"></a>
                            </div>
                            <div class="related-title-and-price text-middle align-middle features-product-row-element">
                            <a href="{$p.url}">
                                <span class="product-title" title="{$p.name}">{$p.name|truncate:50}</span><br>
                                <span class="price">{Tools::displayPrice($p.price)}</span>
                            </a>
                            </div>

                        </div>
                    {/foreach}
                </div>
            </div>
        {/if}
    {/foreach}
    <div class="reasurance-overflow-h-300-clear"></div>
{/if}
<script type="text/javascript" src="/modules/featuredproducts/views/js/script.js?1"></script>
<script>
    var CartLink = '{$cart_link}';
    var CartToken = '{$token}';
    var ProductPrice = '{$productPrice}';
    window.addEventListener('load', function(){
        featuredProducts.productPrice = {$productPrice};
        featuredProducts.init();
    })

</script>
