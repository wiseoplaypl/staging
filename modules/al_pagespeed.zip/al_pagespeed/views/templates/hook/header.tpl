/**
 * header.tpl
 * This file was generated with automatic module generator created by SzpaQ <dev-bot>
 * File is part of module al_pagespeed
 * @author SzpaQ
 * @copyright Since 2007 PrestaShop SA and Contributors
 * @license   https://opensource.org/licenses/AFL-3.0 Academic Free License version 3.0
 * *}