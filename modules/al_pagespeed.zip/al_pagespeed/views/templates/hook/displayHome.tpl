<div class="container">
    <div class="row">
        <div class="col-md-1"></div>
        <div class="col-md-5"><h3 style="padding:8px; background:#2E3F50;color:#fff">Free Delivery Nationwide</h3></div>
        <div class="col-md-5"><h3 style="padding:8px; background:#2E3F50;color:#fff">Shops in Dublin Naas Carlow Gorey Wexford</h3></div>

    </div>
</div>
