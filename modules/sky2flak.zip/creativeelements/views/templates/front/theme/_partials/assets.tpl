{**
 * Creative Elements - live Theme & Page Builder
 *
 * @author    WebshopWorks
 * @copyright 2019-2024 WebshopWorks.com
 * @license   One domain support license
 *}
{if $stylesheets}
    {foreach $stylesheets.external as $stylesheet}
    {if $page.page_name == 'index'}
        {if $stylesheet.id == 'modules-font-mahardhi'}

            <link name="{$stylesheet.id}" rel="stylesheet" href="{$stylesheet.uri}" media="{$stylesheet.media}">
        {else}
            <link name="{$stylesheet.id}" rel="stylesheet" href="{$stylesheet.uri}" media="{$stylesheet.media}">

        {/if}
        {else}
        <link name="{$stylesheet.id}" rel="stylesheet" href="{$stylesheet.uri}" media="{$stylesheet.media}">
    {/if}
    {/foreach}

    {foreach $stylesheets.inline as $id => $stylesheet}
    <style id="{$id}">
        {$stylesheet.content|cefilter}
    </style>
    {/foreach}
{/if}

{assign var="nodef" value=["modules-cookie", "corejs", "theme-main" ]}
{assign var="ignorejs" value=["dbaf683f82df4d0716e5f749995c3bfebc1b845d", "klarnapayment-onsite-messaging", "6a604eca9aac0074a41b59d2e37016652f35ae3e", "f3cebe5b7fb6809474ad8a0d6de5491cf297a48e", "64cd1f7f9d4d0cd8892800467e32772606b5f3c8", "5d97d57aa98e3ae90da963fc29ffd403458135b4", "881dd08aafb161591d82caca182f345c6274290e", "3f8074901a7f44e8f73ef61f1eefbb32f298c7c8", "be12b83da8d75b5e10c3b6bd591b167879e60d6e", "8f17e43acf24650dfdea97359a13805f0119f918", "modules-phsimpleblog", "89cd75b700e33658da70c202d9c2254519974453", "f65c90416d996e8ab3a07915c6a14e33f100e64c" ]}

{foreach $javascript.external as $js}
    {if in_array($js.id, $nodef)}
        <script name="{$js.id}" type="text/javascript" src="{$js.uri}" {$js.attribute}></script>
    {else}
        {if $page.page_name == 'index' && in_array($js.id, $ignorejs)}

        {else}
                <script name="{$js.id}" type="text/javascript" src="{$js.uri}" {$js.attribute} defer></script>
        {/if}
    {/if}
{/foreach}


{foreach $javascript.inline as $js}
    <script>
    {$js.content|cefilter}
    </script>
{/foreach}

{if $js_custom_vars}
    <script>
    {foreach $js_custom_vars as $var_key => $var_val}
        var {$var_key} = {json_encode($var_val)|cefilter};
    {/foreach}
    </script>
{/if}
