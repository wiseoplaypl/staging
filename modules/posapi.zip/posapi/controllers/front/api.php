<?php
/**
 * events.php
 * File generated with module generator by SzpaQ <dev-bot>
 * This file is part od module usercomevents (User.com events)
 * @author SzpaQ
 * @copyright 2019 SzpaQ
 * @license All Rights Reserved
 * */


if (!defined('_PS_VERSION_')) {
    exit;
}

class PosapiApiModuleFrontController extends ModuleFrontController
{
    public $result = [
        'status' => 'ok'
    ];
    public $errorCodes = [
        '001' => 'Unknown Error',
        '002' => 'Method not found',
        '003' => 'Path for file is not set in configuration',
        '004' => 'Supplier not found',
    ];
    public $products = [];
    public $orders = [];
    public $supplierMap = [
        'NaturalSleep' => 'Natural Sleep',
        'DreamWorld' => 'Dream World',
        'Tcs' => 'TCS Royal Coil',
        'Mezz' => 'MEZZ',
    ];
    public static $supplierConnectMap = [
        'Natural Sleep' => [
            'Natural Sleep Mattresses',
            'NS Ascot Divan.Headboard',
            'NS Special Colours D/HB',
        ],
    ];



    public function __construct()
    {
        $this->bootstrap = true;
        parent::__construct();
    }
    public function initContent()
    {
        ini_set('display_errors', 'Off');error_reporting(0);
        if (preg_match('/szpak/', $_SERVER['HTTP_USER_AGENT'])) {

            /**
            header('Content-Type: application/json');
            echo json_encode('ok');
            exit;
            /**/
        }
        parent::initContent();
        /** File generated with Module generator made by SzpaQ */
        if (Tools::getIsset('getSupplierOrder') && Tools::getIsset('product_reference')) {
            $obj = OrderProductSupplier::getByReferences(
                Tools::getValue('product_reference'),
                Tools::getValue('getSupplierOrder')
            );
            if ($obj) {
                exit($obj -> supplier_name);
            }
            exit();
        } elseif (Tools::getIsset('setOrder')) {
            /**/
            header('Content-Type: application/json');
            echo json_encode(self::insertOrder((int) Tools::getValue('setOrder')));
            exit;
            /**/
        } elseif (Tools::getIsset('getProducts')) {
            Context::getContext()->wsb_supplier_name = 1;
            $this->getProducts(Tools::getValue('Supplier'), (bool) Tools::getIsset('Full'));
        } elseif (Tools::getIsset('getPrestashopProducts')) {
            $this->getPrestashopProducts(Tools::getValue('Supplier'));
        } elseif (Tools::getIsset('getOrders')) {
            $this->getOrders(Tools::getValue('getOrders'));
            $this->result['products'] = [];
        }
       /// $this->getOrders(Tools::getValue('id_order'));
        $this->showResult();
    }
    public function getOrders($date = '2021-07-30')
    {
        self::installTable();
        $details = Db::getInstance()->executeS("
            SELECT * FROM ". _DB_PREFIX_ ."order_detail WHERE id_order IN(
                SELECT id_order FROM ". _DB_PREFIX_ ."orders WHERE date_add >= '". $date ."' AND current_state IN(2,21,23)
            )
        ");
        /** check if its supplier */

        /** END check if its supplier */
        if ($details) {
            $this->loadProductsCache();
        }
        $this->result['orders'] = [];
        foreach ($details as $detail) {
         //   if (isset($this->result['products'][$detail['product_reference']])) {
              //  $this->result['products'][$detail['product_reference']]['name'] .= ' ( '. $detail['product_name'] .' )';
                $order = new Order($detail['id_order']);
                $customerDetails = null;
                $orderDetails = null;
                $orderPayment = null;
                if (Tools::getIsset('customer_details')) {
                    $customerDetails = [
                        'customer' => new Customer($order->id_customer),
                        'address_delivery' => new Address($order->id_address_delivery),
                        'address_invoice' => new Address($order->id_address_invoice),
                    ];
                }
                if (Tools::getIsset('order_details')) {
                    $orderDetails = Db::getInstance()->executeS("
                        SELECT
                            product_quantity,
                            unit_price_tax_incl,
                            total_price_tax_incl,
                            product_name,
                            product_reference
                        FROM ". _DB_PREFIX_ ."order_detail
                        WHERE id_order = '". $order->id ."'
                    ");
                    $orderPayment = Db::getInstance()->getRow("SELECT * FROM ". _DB_PREFIX_ ."order_payment WHERE order_reference = '". $order->reference ."'");
                }
                $orderPayment['total_discount'] = $order->total_discounts_tax_incl;
                $this->result['orders'][] = [
                    'id_order' => $order->id,
                    'payment' => $order->payment,
                    'order_state' => $order->current_state,
                    'order_reference' => $order->reference,
                    'total_discount' => $order->total_discounts_tax_incl,
                    'quantity' => $detail['product_quantity'],
                    'product' => $this->result['products'][$detail['product_reference']],
                    'prestashop_name' => $detail['product_name'],
                    'customer_details' =>  $customerDetails,
                    'payment_details' =>  $orderPayment,
                    'orderDetails' =>  $orderDetails,
                    'total_shipping' => $order->total_shipping
                ];
         //  }
         //   self::insertOrder($detail['id_order']);
        }
        $arrContextOptions=array(
            "ssl"=>array(
                "verify_peer"=>false,
                "verify_peer_name"=>false,
            ),
        );
        if (!Tools::getIsset('topos')) {
            $file = json_decode(file_get_contents('http://stock.liquidationfurniture.ie/apii.php?get_orders='. $date, false, stream_context_create($arrContextOptions)));

           // $this->result['orders'] =[];
            foreach ($file as $posOrder) {
                foreach ($posOrder->sale_items as $item) {
                        $id_product = false;
                        $subname = false;
                        $id_product_attribute = Db::getInstance()->getValue("
                            SELECT id_product_attribute FROM ". _DB_PREFIX_ ."product_attribute WHERE reference = '". $item -> product_code ."'
                        ");
                        if ($id_product_attribute) {
                            $combination = new Combination($id_product_attribute);
                            $subname = [];
                            foreach ($combination->getAttributesName(Configuration::get('PS_LANG_DEFAULT')) as $v) {
                                $subname[] = $v['name'];
                            }
                            $subname = implode(', ', $subname);
                            $id_product = $combination -> id_product;
                        } else {
                            $id_product = Db::getInstance()->getValue("
                                SELECT id_product FROM ". _DB_PREFIX_ ."product WHERE reference = '". $item -> product_code ."'
                            ");
                        }
                        if ($id_product) {
                            $product = new Product($id_product);
                            $item->product_name = $product->name[Configuration::get('PS_LANG_DEFAULT')];
                            if ($subname) {
                                $item->product_name .= ' - '. $subname;
                            }
                        }

                    $this->result['orders'][] = [
                        'id_order' => '9999999' . $posOrder->id,
                        'order_state' => 2,
                        'order_reference' => 'POS_'. $posOrder->reference_no,
                        'quantity' => $item->quantity,
                        'product' => $this->result['products'][$item->product_code],
                        'prestashop_name' => $item->product_name,
                        'ref' => $item->product_code
                    ];
                }
            }
        }

        /**
        header('Content-Type: application/json');
        echo json_encode([$this->result]);
        exit;
        /**/
        /**
        header('Content-Type: application/json');
        echo json_encode($this->result['orders']);
        exit;
        /**/

        /**
        header('Content-Type: application/json');
        echo json_encode($this->result['orders']);
        exit;
        /**/
    }
    public static function installTable()
    {
        return Db::getInstance()->execute(
            "CREATE TABLE IF NOT EXISTS "._DB_PREFIX_."order_max_order (
                `id_order` INT(10) NULL,
                PRIMARY KEY (`id_order`)
             )"

        );
    }
    public static function insertOrder($id_order)
    {
        return Db::getInstance()->execute(
            "INSERT IGNORE INTO "._DB_PREFIX_."order_max_order (
                `id_order`
            ) VALUES('". pSQL($id_order) ."')"
        );
    }
    public function loadProductsCache()
    {
        return;
        $suppliers = ['Brw', 'Halmar', 'Wsb', 'Decor', 'NaturalSleep', 'DreamWorld'];
        $file = dirname(__FILE__) .'/../../products3.cache';
        if (file_exists($file)) {
            if (filemtime($file) > time() - 3600) {
                $this->result['products'] = json_decode(file_get_contents($file), true);
                return;
            }
        }
        foreach ($suppliers as $v) {
            $this->getProducts($v);
        }
        file_put_contents($file, json_encode($this->result['products']));
    }
    public function getProductsFull($supplier = null)
    {

    }
    public function getProducts($class = 'Brw', $full = true)
    {
        if (isset(self::$supplierConnectMap[$class])) {
            $class = self::$supplierConnectMap[$class];
        }
        if (class_exists($class) && method_exists($class, 'loadProducts')) {
            if (!Configuration::get('POSApi_'. $class)) {
                $this->throwError('003');
            }
            $object = new $class(Configuration::get('POSApi_'. $class));
            $object -> loadProducts();
            if ($full === true) {
                $this->loadPrestashopProducts($class);
                $products = [];
                foreach ($object->products as $k => $v) {

                    $v = (object) $v;
                    if (!isset($this->products[$v->reference])) {
                        $this->products[$v->reference] = $this->getProductFromCombination($v->reference);
                    }
                    $our_price = '';
                    if (isset($v->price) && $v->price) {
                        $our_price = $v->price;
                    }
                    $this->result['products'][$v->reference] = [
                        'reference' => $v->reference,
                        'name' => $v->name,
                        'supplier' => $class,
                        'prestashop_name' => isset($this->products[$v->reference]) ? $this->products[$v->reference]['name'] : '',
                        'price' => $v->price_before,
                        'prestashop_price' => isset($this->products[$v->reference]) ? $this->products[$v->reference]['price'] : '',
                        'price_default' => isset($this->products[$v->reference]['price_default']) ? $this->products[$v->reference]['price_default'] : '',
                        'quantity' => $v->quantity,
                        'prestashop_quantity' => isset($this->products[$v->reference]) ? $this->products[$v->reference]['quantity'] : '',
                        'is_prestashop' => (bool) isset($this->products[$v->reference]),
                        'default_our_price' => $our_price,
                    ];

                    /**
                    header('Content-Type: application/json');
                    echo json_encode($this->result['products'][$v->reference]);
                    exit;
                    /**/
                }

                /**
                header('Content-Type: application/json');
                echo json_encode($this->result['products']);
                exit;
                /**/
              //  $this->result['products'] = $products;
                return;
            }
            foreach ($object -> products as $v) {
                //$this->result['products'][$v['reference']] = $v;
            }

        } else {
            $this->throwError('004');
        }
    }
    public function getProductFromCombination($reference)
    {
        $id_product_attribute = Db::getInstance()->getValue("
            SELECT id_product_attribute
            FROM ". _DB_PREFIX_ ."product_attribute
            WHERE reference = '". $reference ."'
        ");
        if ($id_product_attribute) {
            $combination = new Combination($id_product_attribute);

            /**
            header('Content-Type: application/json');
            echo json_encode();
            exit;
            /**/
            $product = new Product($combination->id_product);
            $name = $product->name[Context::getContext()->language->id];
            foreach ($combination->getAttributesName(Context::getContext()->language->id) as $v) {
                $name .= ' - '. $v['name'];
            }
            return [
                'name' => $name,//$product->name[Context::getContext()->language->id],
                'price' => $product->getPrice(true, $combination->id),//$combination->price,
                'price_default' => $product->getPrice(true, $combination->id, 6, null, false, false),//$combination->price,
                'quantity' => StockAvailable::getQuantityAvailableByProduct($product->id, $combination->id),
            ];
            /**
            header('Content-Type: application/json');
            echo json_encode();
            exit;
            /**/
        }
        return [
            'name' => '',
            'price' => '',
            'quantity' => '',
        ];
    }
    public function getPrestashopProducts($supplier = null)
    {
        $this->result['products'] = $this->loadPrestashopProducts($supplier);
    }
    public function loadPrestashopProducts($supplier)
    {
        $this->products = [];
        if ($supplier) {
            if (isset($this->supplierMap[$supplier])) {
                $supplier = $this->supplierMap[$supplier];
            }
            $subquery = '';
            if (isset(self::$supplierConnectMap[$supplier])) {
                $subquery .= " OR name LIKE '";
                $subquery .= implode("' OR name LIKE '", self::$supplierConnectMap[$supplier]);
                $subquery .= "'";

            }
            $id_suppliers = Db::getInstance()->executeS("SELECT id_supplier FROM ". _DB_PREFIX_ ."supplier WHERE name LIKE '". $supplier ."'". $subquery);
            $suppliers_id = [];
            foreach ($id_suppliers as $v) {
                $suppliers_id[] = $v['id_supplier'];
            }
            if (empty($suppliers_id)) {
                $this->throwError('004');
            }

            $products = Db::getInstance()->executeS("
                SELECT id_product FROM ". _DB_PREFIX_ ."product WHERE id_product IN(
                    SELECT id_product FROM ". _DB_PREFIX_ ."product_supplier
                    WHERE id_supplier IN(2, ". implode(',', $suppliers_id) .")

                )
            ");
            foreach ($products as $v) {
                $product = new Product($v['id_product']);
                $this->products[$product->reference] = [
                    'reference' => $product -> reference,
                    'name' => array_shift($product->name),
                    'price' => $product->getPrice(true),
                    'price_default' => $product->getPrice(true, null, 6, null, false, false),
                    'quantity' => StockAvailable::getQuantityAvailableByProduct($product->id),
                ];
            }
        } else {
            $products = Db::getInstance()->executeS("SELECT id_product FROM ". _DB_PREFIX_."product");
            foreach ($products as $v) {
                $product = new Product($v['id_product']);
                $this->products[$product->reference] = [
                    'reference' => $product -> reference,
                    'name' => array_shift($product->name),
                    'price' => $product->getPrice(true),
                    'price_default' => $product->getPrice(true, null, 6, null, false, false),
                    'quantity' => StockAvailable::getQuantityAvailableByProduct($product->id),
                ];
            }
            /*
             *$tax = true,
        $id_product_attribute = null,
        $decimals = 6,
        $divisor = null,
        $only_reduc = false,
        $usereduc = true,
             *
             * */
        }
        return $this->products;
    }
    public function throwError($code)
    {
        if (!isset($this->errorCodes[$code])) {
            return $this->throwError('001');
        }
        $this->result['status'] = 'ERROR';
        $this->result['error_code'] = $code;
        $this->result['error_message'] = $this->errorCodes[$code];
        /**/
        header('Content-Type: application/json');
        echo json_encode($this->result);
        exit;
        /**/
    }
    public function showResult($data = [])
    {

        $this->result = array_merge($this->result, $data);
        /**/
        header('Content-Type: application/json');
        echo json_encode($this->result);
        exit;
        /**/
    }
}
