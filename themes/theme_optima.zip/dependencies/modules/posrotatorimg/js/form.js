$(document).ready(function() {
    form.init(), nav.init(), featuresCollection.init(), displayFormCategory.init(), formCategory.init(), stock.init(), supplier.init(), specificPrices.init(), warehouseCombinations.init(), customFieldCollection.init(), virtualProduct.init(), attachmentProduct.init(), imagesProduct.init(), priceCalculation.init(), displayFieldsManager.refresh(), displayFieldsManager.init(virtualProduct), seo.init(), tags.init(), rightSidebar.init(), recommendedModules.init(), BOEvent.emitEvent("Product Categories Management started", "CustomEvent"), BOEvent.emitEvent("Product Default category Management started", "CustomEvent"), BOEvent.emitEvent("Product Manufacturer Management started", "CustomEvent"), BOEvent.emitEvent("Product Related Management started", "CustomEvent"), BOEvent.emitEvent("Modal confirmation started", "CustomEvent"), BOEvent.emitEvent("Product Combinations Management started", "CustomEvent"), rotator.getidrotator(), $("#form_step1_type_product").change(function() {
        displayFieldsManager.refresh()
    }), $(".money-type input[type='text']").change(function() {
        var t = priceCalculation.normalizePrice($(this).val()),
            t = truncateDecimals(t, 6);
        $(this).val(t)
    }), $(".datepicker").datetimepicker({
        locale: full_language_code,
        format: "YYYY-MM-DD"
    }), $("#form-nav").on("click", ".nav-item", function() {
        $('[data-toggle="tooltip"]').tooltip("hide"), $('[data-toggle="popover"]').popover("hide")
    })
});
var displayFieldsManager = function() {
        var e, a = $("#form_step1_type_product"),
            i = $("#show_variations_selector"),
            t = $("#combinations");
        return {
            init: function(t) {
                e = t, $("#form_step1_type_product").change(function() {
                    displayFieldsManager.refresh()
                }), $("#form .form-input-title input").on("focus", function() {
                    $(this).select()
                }), this.initVisibilityRule(), $("a#tax_rule_shortcut_opener").on("click", function() {
                    var t, e = $("#form_step2_id_tax_rules_group_shortcut");
                    return 0 == e.length && (t = $("select#form_step2_id_tax_rules_group"), e = t.clone(!1).attr("id", "form_step2_id_tax_rules_group_shortcut"), t.on("change", function() {
                        e.val(t.val())
                    }), e.on("change", function() {
                        t.val(e.val()).change()
                    }), e.appendTo($("#tax_rule_shortcut"))), e.parent().parent().show(), !1
                })
            },
            initVisibilityRule: function() {
                function t() {
                    var t = $(r + " input"),
                        e = $(i + " input"),
                        a = $(i);
                    t.prop("checked") ? (e.prop("checked", !0), a.addClass("hide")) : a.removeClass("hide")
                }
                var i = ".js-show-price",
                    r = ".js-available-for-order";
                $(r + " .checkbox").on("click", t), t()
            },
            refresh: function() {
                this.checkAccessVariations(), $("#virtual_product").hide(), $('#form-nav a[href="#step3"]').text(translate_javascripts.Quantities), "1" === a.val() ? ($("#pack_stock_type, #js_form_step1_inputPackItems").show(), $('#form-nav a[href="#step4"]').show(), i.hide(), i.find('input[value="0"]').attr("checked", !0)) : ($("#virtual_product, #pack_stock_type, #js_form_step1_inputPackItems").hide(), $('#form-nav a[href="#step4"]').show(), "2" === a.val() ? (i.hide(), $("#virtual_product").show(), $('#form-nav a[href="#step4"]').hide(), i.find('input[value="0"]').attr("checked", !0), $('#form-nav a[href="#step3"]').text(translate_javascripts["Virtual product"])) : (i.show(), $('#form-nav a[href="#step3"]').text(translate_javascripts.Quantities))), "2" !== a.val() && void 0 !== e && e.destroy(), "1" === i.find("input:checked").val() || 0 < $("#accordion_combinations tr:not(#loading-attribute)").length ? (t.show(), $("#specific-price-combination-selector").removeClass("hide").show(), $('#form-nav a[href="#step3"]').text(translate_javascripts.Combinations), $("#product_qty_0_shortcut_div, #quantities").hide()) : (t.hide(), $("#specific-price-combination-selector").hide(), $("#product_qty_0_shortcut_div, #quantities").show()), 1 <= $('input[name="show_variations"][value="1"]:checked').length ? $("#product_type_combinations_shortcut").show() : $("#product_type_combinations_shortcut").hide()
            },
            getProductType: function() {
                switch (a.val()) {
                    case "0":
                        return "standard";
                    case "1":
                        return "pack";
                    case "2":
                        return "virtual";
                    default:
                        return "standard"
                }
            },
            checkAccessVariations: function() {
                var t;
                !("1" === i.find("input:checked").val() || 0 < $("#accordion_combinations tr:not(#loading-attribute)").length) || "1" !== a.val() && "2" !== a.val() || (t = this.getProductType(), modalConfirmation.create(translate_javascripts["You can't create " + t + " product with variations. Are you sure to disable variations ? they will all be deleted."], null, {
                    onCancel: function() {
                        a.val(0).change(), $('#show_variations_selector input[value="1"]').click()
                    },
                    onContinue: function() {
                        $.ajax({
                            type: "GET",
                            url: $("#accordion_combinations").attr("data-action-delete-all").replace(/delete-all\/\d+/, "delete-all/" + $("#form_id_product").val()),
                            success: function() {
                                $("#accordion_combinations .combination").remove(), displayFieldsManager.refresh()
                            },
                            error: function(t) {
                                showErrorMessage(jQuery.parseJSON(t.responseText).message)
                            }
                        })
                    }
                }).show())
            }
        }
    }(),
    displayFormCategory = function() {
        var e = $("#add-categories");
        return {
            init: function() {
                e.find("a.open").on("click", function(t) {
                    t.preventDefault(), e.find("#add-categories-content").removeClass("hide"), $(this).hide()
                })
            }
        }
    }(),
    formCategory = function() {
        var e = $("#form_step1_new_category");
        return {
            init: function() {
                var t = this;
                $("#add-categories button.save").click(function() {
                    var i;
                    i = t, $.ajax({
                        type: "POST",
                        url: e.attr("data-action"),
                        data: {
                            "form[category][name]": $("#form_step1_new_category_name").val(),
                            "form[category][id_parent]": $("#form_step1_new_category_id_parent").val(),
                            "form[_token]": $("#form #form__token").val()
                        },
                        beforeSend: function() {
                            $("button.submit", e).attr("disabled", "disabled"), $("ul.text-danger", e).remove(), $("*.has-danger", e).removeClass("has-danger"), $("*.has-danger").removeClass("has-danger")
                        },
                        success: function(t) {
                            var e = '<li><div class="checkbox js-checkbox"><label><input type="checkbox" name="form[step1][categories][tree][]" checked value="' + t.category.id + '"> ' + t.category.name[1] + '<input type="radio" value="' + t.category.id + '" name="ignore" class="default-category"></label></div></li>',
                                a = $("#form_step1_categories input[value=" + t.category.id_parent + "]").parent().parent(),
                                a = (0 === a.next("ul").length ? a.append(e = "<ul>" + e + "</ul>") : a.next("ul").append(e), $("#form_step1_new_category_id_parent").append('<option value="' + t.category.id + '">' + t.category.name[1] + "</option>"), {
                                    name: t.category.name[1],
                                    id: t.category.id,
                                    breadcrumb: ""
                                });
                            productCategoriesTags.createTag(a), i.hideBlock()
                        },
                        error: function(t) {
                            $.each(jQuery.parseJSON(t.responseText), function(t, e) {
                                var a = '<ul class="list-unstyled text-danger">';
                                $.each(e, function(t, e) {
                                    a += "<li>" + e + "</li>"
                                }), a += "</ul>", $("#form_step1_new_" + t).parent().append(a), $("#form_step1_new_" + t).parent().addClass("has-danger")
                            })
                        },
                        complete: function() {
                            $("#form_step1_new_category button.submit").removeAttr("disabled")
                        }
                    })
                }), $('#add-categories button[type="reset"]').click(function() {
                    t.hideBlock()
                })
            },
            hideBlock: function() {
                $("#form_step1_new_category_name").val(""), $("#add-category-button").show(), $("#add-categories-content").addClass("hide")
            }
        }
    }(),
    featuresCollection = function() {
        var e = $(".feature-collection");
        return {
            init: function() {
                $("#features .add").on("click", function(t) {
                    t.preventDefault(), t = e.attr("data-prototype").replace(/__name__/g, e.children(".row").length), e.append(t), prestaShopUiKit.initSelects(), $("#features-content").removeClass("hide")
                }), $(document).on("click", ".feature-collection .delete", function(t) {
                    t.preventDefault();
                    var e = $(this);
                    modalConfirmation.create(translate_javascripts["Are you sure to delete this?"], null, {
                        onContinue: function() {
                            e.closest(".product-feature").remove()
                        }
                    }).show()
                }), $(document).on("change", ".feature-collection select.feature-selector", function(t) {
                    var t = t.currentTarget,
                        a = $($(t).parents(".row")[0]).find(".feature-value-selector");
                    "" !== $(this).val() && $.ajax({
                        url: $(this).attr("data-action").replace(/\/\d+(?=\?.*)/, "/" + $(this).val()),
                        success: function(t) {
                            a.prop("disabled", 0 === t.length), a.empty(), $.each(t, function(t, e) {
                                "0" == e.id && (e.id = ""), a.append($("<option></option>").attr("value", e.id).text(e.value))
                            })
                        }
                    })
                }), $("#features-content").on("change", '.row select, .row input[type="text"]', function(t) {
                    var t = t.currentTarget,
                        e = $($(t).parents(".row")[0]),
                        a = e.find(".feature-value-selector"),
                        e = e.find("input[type=text]");
                    $(t).hasClass("feature-selector") && (e.val(""), a.val(""))
                })
            }
        }
    }(),
    supplier = function() {
        function t(t) {
            var e = $('#form_step6_suppliers input[name="form[step6][default_supplier]"][value=' + $(t).val() + "]");
            $(t).is(":checked") ? e.prop("disabled", !1).show() : e.prop("disabled", !0).hide()
        }
        return {
            init: function() {
                $('#form_step6_suppliers input[name="form[step6][suppliers][]"]').change(function() {
                    t($(this)), supplierCombinations.refresh()
                }), $('#form_step6_suppliers input[name="form[step6][suppliers][]"]').map(function() {
                    t($(this))
                })
            }
        }
    }(),
    supplierCombinations = function() {
        var e = $("#form_id_product").val(),
            a = $("#supplier_combination_collection");
        return {
            refresh: function() {
                var t = $('#form_step6_suppliers input[name="form[step6][suppliers][]"]:checked').map(function() {
                        return $(this).val()
                    }).get(),
                    t = a.attr("data-url").replace(/refresh-product-supplier-combination-form\/\d+\/\d+/, "refresh-product-supplier-combination-form/" + e + (0 < t.length ? "/" + t.join("-") : ""));
                $.ajax({
                    url: t,
                    success: function(t) {
                        a.empty().append(t)
                    }
                })
            }
        }
    }(),
    stock = {
        init: function() {
            $("#form_step1_qty_0_shortcut, #form_step3_qty_0").keyup(function() {
                ("form_step1_qty_0_shortcut" === $(this).attr("id") ? $("#form_step3_qty_0") : $("#form_step1_qty_0_shortcut")).val($(this).val())
            }), $("#form_step3_advanced_stock_management").on("change", function(t) {
                t.target.checked ? $("#depends_on_stock_div").show() : $("#depends_on_stock_div").hide(), warehouseCombinations.refresh()
            }), $("#form_step3_depends_on_stock_0, #form_step3_depends_on_stock_1, #form_step3_advanced_stock_management").on("change", function(t) {
                displayFieldsManager.refresh(), warehouseCombinations.refresh()
            }), displayFieldsManager.refresh()
        }
    },
    nav = {
        init: function() {
            var t = document.location.hash,
                e = $("#form-nav");
            t && e.find("a[href='" + t.replace("tab-", "") + "']").tab("show"), e.find("a").on("shown.bs.tab", function(t) {
                t.target.hash && ("#step2" === t.target.hash && specificPrices.refreshCombinationsList(), window.location.hash = t.target.hash.replace("#", "#tab-"))
            })
        }
    },
    specificPrices = function() {
        var e = $("#form_id_product").val(),
            i = $("#js-specific-price-list"),
            t = $("#form_step2_specific_price_leave_bprice"),
            a = $("#form_step2_specific_price_sp_price"),
            r = $("#form_step2_specific_price_sp_reduction_type"),
            o = ($("#form_step2_specific_price_sp_reduction_tax"), new Object);

        function n() {
            var t = i.attr("data").replace(/list\/\d+/, "list/" + e);
            $.ajax({
                type: "GET",
                url: t,
                success: function(t) {
                    var a = i.find("tbody");
                    a.find("tr").remove(), 0 < t.length ? i.removeClass("hide") : i.addClass("hide"), $.each(t, function(t, e) {
                        e = "<tr><td>" + e.rule_name + "</td><td>" + e.attributes_name + "</td><td>" + e.currency + "</td><td>" + e.country + "</td><td>" + e.group + "</td><td>" + e.customer + "</td><td>" + e.fixed_price + "</td><td>" + e.impact + "</td><td>" + e.period + "</td><td>" + e.from_quantity + "</td><td>" + (e.can_delete ? '<a href="' + $("#js-specific-price-list").attr("data-action-delete").replace(/delete\/\d+/, "delete/" + e.id_specific_price) + '" class="js-delete delete btn tooltip-link delete pl-0 pr-0"><i class="material-icons">delete</i></a>' : "") + "</td></tr>";
                        a.append(e)
                    })
                }
            })
        }

        function c() {
            $("#specific_price_form").find("input").each(function() {
                $(this).val(o[$(this).attr("id")])
            }), $("#specific_price_form").find("select").each(function() {
                $(this).val(o[$(this).attr("id")]).change()
            }), $("#specific_price_form").find("input:checkbox").each(function() {
                $(this).prop("checked", !0)
            })
        }
        return {
            init: function() {
                this.getAll(), $("#specific-price .add").click(function() {
                    $(this).hide()
                }), $("#specific_price_form .js-cancel").click(function() {
                    c(), $("#specific-price > a").click(), $("#specific-price .add").click().show(), a.prop("disabled", !0)
                }), $("#specific_price_form .js-save").click(function() {
                    var t;
                    t = $(this), $.ajax({
                        type: "POST",
                        url: $("#specific_price_form").attr("data-action"),
                        data: $("#specific_price_form input, #specific_price_form select, #form_id_product").serialize(),
                        beforeSend: function() {
                            t.attr("disabled", "disabled")
                        },
                        success: function() {
                            showSuccessMessage(translate_javascripts["Form update success"]), $("#specific_price_form .js-cancel").click(), n()
                        },
                        complete: function() {
                            t.removeAttr("disabled")
                        },
                        error: function(t) {
                            showErrorMessage(t.responseJSON)
                        }
                    })
                }), $(document).on("click", "#js-specific-price-list .js-delete", function(t) {
                    var e;
                    t.preventDefault(), e = $(this), modalConfirmation.create(translate_javascripts["This will delete the specific price. Do you wish to proceed?"], null, {
                        onContinue: function() {
                            $.ajax({
                                type: "GET",
                                url: e.attr("href"),
                                beforeSend: function() {
                                    e.attr("disabled", "disabled")
                                },
                                success: function(t) {
                                    n(), c(), showSuccessMessage(t)
                                },
                                error: function(t) {
                                    showErrorMessage(t.responseJSON)
                                },
                                complete: function() {
                                    e.removeAttr("disabled")
                                }
                            })
                        }
                    }).show()
                }), $("#form_step2_specific_price_sp_reduction_type").change(function() {
                    "percentage" === $(this).val() ? $("#form_step2_specific_price_sp_reduction_tax").hide() : $("#form_step2_specific_price_sp_reduction_tax").show()
                }), this.refreshCombinationsList(), t.on("click", function() {
                    a.prop("disabled", $(this).is(":checked")).val("")
                }), r.on("change", function() {
                    var t = $("#select2-form_step2_specific_price_sp_reduction_tax-container").parent().parent();
                    "amount" === $(this).val() ? t.show() : t.hide()
                }), this.getInitSpecificPriceForm()
            },
            getAll: function() {
                n()
            },
            refreshCombinationsList: function() {
                var a, t;
                a = $("#form_step2_specific_price_sp_id_product_attribute"), t = a.attr("data-action").replace(/product-combinations\/\d+/, "product-combinations/" + e), $.ajax({
                    type: "GET",
                    url: t,
                    success: function(t) {
                        a.find("option:gt(0)").remove(), $.each(t, function(t, e) {
                            a.append('<option value="' + e.id + '">' + e.name + "</option>")
                        })
                    }
                })
            },
            getInitSpecificPriceForm: function() {
                $("#specific_price_form").find("select,input").each(function() {
                    o[$(this).attr("id")] = $(this).val()
                }), $("#specific_price_form").find("input:checkbox").each(function() {
                    o[$(this).attr("id")] = $(this).prop("checked")
                })
            }
        }
    }(),
    warehouseCombinations = function() {
        var e = $("#form_id_product").val(),
            a = $("#warehouse_combination_collection");
        return {
            init: function() {
                $(document).on("click", 'div[id^="warehouse_combination_"] button.check_all_warehouse', function() {
                    var t = $(this).closest('div[id^="warehouse_combination_"]').find('input[type="checkbox"][id$="_activated"]');
                    t.prop("checked", 0 === t.filter(":checked").length)
                }), $(document).on("change", 'div[id^="warehouse_combination_"] input[id^="form_step4_warehouse_combination_"][id$="_activated"]', function() {
                    var t = $(this).prop("checked"),
                        e = $(this).closest("div.form-group").find('input[id^="form_step4_warehouse_combination_"][id$="_location"]');
                    e.prop("disabled", !t), t || e.val("")
                }), this.locationDisabler()
            },
            locationDisabler: function() {
                $('div[id^="warehouse_combination_"] input[id^="form_step4_warehouse_combination_"][id$="_activated"]', a).each(function() {
                    var t = $(this).prop("checked");
                    $(this).closest("div.form-group").find('input[id^="form_step4_warehouse_combination_"][id$="_location"]').prop("disabled", !t)
                })
            },
            refresh: function() {
                var t;
                0 < $("input#form_step3_advanced_stock_management:checked").length ? (t = a.attr("data-url").replace(/\/\d+(?=\?.*)/, "/" + e), $.ajax({
                    url: t,
                    success: function(t) {
                        a.empty().append(t), a.show(), warehouseCombinations.locationDisabler()
                    }
                })) : a.hide()
            }
        }
    }(),
    form = function() {
        var n = $("#form");

        function i(e, r, a) {
            void 0 === r && (r = !1), seo.onSave(), t = $("#form_step1_names"), i = null, $("input[id^='form_step1_name_']", t).each(function(t) {
                var e = $(this).val();
                0 === t ? i = e : 0 === e.length && $(this).val(i)
            });
            var i, o, t = $("input, textarea, select", n).not(":input[type=button], :input[type=submit], :input[type=reset]").serialize();
            "_blank" == r && e && (o = window.open("about:blank", r, "")).document.write('<p style="text-align: center;"><img src="' + document.location.origin + baseAdminDir + '/themes/default/img/spinner.gif"></p>'), $.ajax({
                type: "POST",
                data: t,
                beforeSend: function() {
                    $("#submit", n).attr("disabled", "disabled"), $(".btn-submit", n).attr("disabled", "disabled"), $("ul.text-danger").remove(), $("*.has-danger").removeClass("has-danger"), $("#form-nav li.has-error").removeClass("has-error")
                },
                success: function(t) {
                    a && a(), showSuccessMessage(translate_javascripts["Form update success"]), void 0 !== t.customization_fields_ids && $.each(t.customization_fields_ids, function(t, e) {
                        $("#form_step6_custom_fields_" + t + "_id_customization_field").val(e)
                    }), $(".js-spinner").hide(), e && (!1 === r ? window.location = e : "_blank" !== r ? window.open(e, r) : o.location = e)
                },
                error: function(t) {
                    showErrorMessage(translate_javascripts["Form update errors"]), "_blank" == r && e && o.close();
                    var a, i = [];
                    $.each(jQuery.parseJSON(t.responseText), function(t, e) {
                        i.push(t);
                        var a = '<ul class="list-unstyled text-danger">';
                        $.each(e, function(t, e) {
                            a += "<li>" + e + "</li>"
                        }), a += "</ul>", (t.match(/^combination_.*/) ? $("#" + t) : $("#form_" + t)).parent().addClass("has-danger").append(a)
                    }), i.sort(), $.each(i, function(t, e) {
                        0 === t && $('#form-nav li a[href="#' + e.split("_")[0] + '"]').tab("show"), $('#form-nav li a[href="#' + e.split("_")[0] + '"]').parent().addClass("has-error")
                    }), 0 < $('div[class*="translation-label-"].has-danger').length && (a = "translation-label-", t = $.grep($('div[class*="translation-label-"].has-danger').first().attr("class").split(" "), function(t, e) {
                        return 0 === t.indexOf(a)
                    }).join()) && (t = t.replace(a, ""), 0 < $('#form_switch_language option[value="' + t + '"]').length) && $("#form_switch_language").val(t).change(), $(".has-danger").first().offset() && $("html, body").animate({
                        scrollTop: $(".has-danger").first().offset().top - $("nav.main-header").height()
                    }, 500)
                },
                complete: function() {
                    $("#submit", n).removeAttr("disabled"), $(".btn-submit", n).removeAttr("disabled")
                }
            })
        }

        function e(t) {
            $("div.translations.tabbable > div > div.translation-field:not(.translation-label-" + t + ")").removeClass("visible"), $("div.translations.tabbable > div > div.translation-field.translation-label-" + t).addClass("visible")
        }
        return {
            init: function() {
                jwerty.key("enter", function(t) {
                    t.preventDefault()
                }), jwerty.key("alt+shift+S", function(t) {
                    t.preventDefault(), i()
                }), jwerty.key("alt+shift+D", function(t) {
                    t.preventDefault(), i($(".product-footer .duplicate").attr("data-redirect"))
                }), jwerty.key("alt+shift+P", function(t) {
                    t.preventDefault(), i($(".product-footer .new-product").attr("data-redirect"))
                }), jwerty.key("alt+shift+Q", function(t) {
                    t.preventDefault(), i($(".product-footer .go-catalog").attr("data-redirect"))
                }), jwerty.key("alt+shift+V", function(t) {
                    t.preventDefault();
                    t = $(".product-footer .preview");
                    i(t.attr("data-redirect"), t.attr("target"))
                }), jwerty.key("alt+shift+O", function(t) {
                    t.preventDefault();
                    t = $("#form_step1_active");
                    t.prop("checked", !t.is(":checked"))
                }), n.submit(function(t) {
                    t.preventDefault(), i()
                }), n.find("#form_switch_language").change(function(t) {
                    t.preventDefault(), e(t.target.value)
                }), $(".btn-submit, .preview", n).click(function(t) {
                    t.preventDefault(), i($(this).attr("data-redirect"), $(this).attr("target"))
                }), $(".js-btn-save").on("click", function(t) {
                    t.preventDefault(), $(".js-spinner").css("display", "inline-block"), i($(this).attr("href"))
                }), $("#form_step1_active", n).on("change", function() {
                    var t = $(this).prop("checked"),
                        t = ($(".for-switch.online-title").toggle(t), $(".for-switch.offline-title").toggle(!t), $("#product_form_preview_btn")),
                        e = t.attr("data-redirect"),
                        a = t.attr("data-url-deactive");
                    t.attr("data-redirect", a), t.attr("data-url-deactive", e), i()
                }), $(".product-footer .delete", n).click(function(t) {
                    t.preventDefault();
                    var e = $(this);
                    modalConfirmation.create(translate_javascripts["Are you sure to delete this?"], null, {
                        onContinue: function() {
                            window.location = e.attr("href")
                        }
                    }).show()
                }), $("#form-loading").fadeIn(function() {
                    var a = new Bloodhound({
                            datumTokenizer: function(t) {
                                return Bloodhound.tokenizers.whitespace(t.label)
                            },
                            queryTokenizer: Bloodhound.tokenizers.whitespace,
                            prefetch: {
                                url: $("#form_step3_attributes").attr("data-prefetch"),
                                cache: !1
                            }
                        }),
                        i = ($("#form_step3_attributes").tokenfield({
                            typeahead: [{
                                hint: !1,
                                cache: !1
                            }, {
                                source: function(t, e) {
                                    a.search(t, function(t) {
                                        e(i(t))
                                    })
                                },
                                display: "label"
                            }],
                            minWidth: "768px"
                        }), function(t) {
                            var e = [];
                            return $("#attributes-generator input.attribute-generator").each(function() {
                                e.push($(this).val())
                            }), $.grep(t, function(t) {
                                return -1 === $.inArray(t.value, e) && -1 === $.inArray("group-" + t.data.id_group, e)
                            })
                        });
                    $("#form_step3_attributes").on("tokenfield:createtoken", function(t) {
                        if (!t.attrs.data && "tokenfield:createtoken" !== t.handleObj.origType) return !1
                    }), $("#form_step3_attributes").on("tokenfield:createdtoken", function(t) {
                        t.attrs.data ? $("#attributes-generator").append('<input type="hidden" id="attribute-generator-' + t.attrs.value + '" class="attribute-generator" value="' + t.attrs.value + '" name="options[' + t.attrs.data.id_group + "][" + t.attrs.value + ']" />') : "tokenfield:createdtoken" == t.handleObj.origType && $("#attributes-generator").append('<input type="hidden" id="attribute-generator-' + $('.js-attribute-checkbox[data-value="' + t.attrs.value + '"]').data("value") + '" class="attribute-generator" value="' + $('.js-attribute-checkbox[data-value="' + t.attrs.value + '"]').data("value") + '" name="options[' + $('.js-attribute-checkbox[data-value="' + t.attrs.value + '"]').data("group-id") + "][" + $('.js-attribute-checkbox[data-value="' + t.attrs.value + '"]').data("value") + ']" />')
                    }), $("#form_step3_attributes").on("tokenfield:removedtoken", function(t) {
                        $("#attribute-generator-" + t.attrs.value).remove()
                    })
                })
            },
            send: function(t, e, a) {
                i(t, e, a)
            },
            switchLanguage: function(t) {
                e(t)
            }
        }
    }(),
    customFieldCollection = function() {
        var e = $("ul.customFieldCollection");
        return {
            init: function() {
                $("#custom_fields a.add").on("click", function(t) {
                    t.preventDefault(), t = e.attr("data-prototype").replace(/__name__/g, e.children().length), e.append("<li>" + t + "</li>")
                }), $(document).on("click", "ul.customFieldCollection .delete", function(t) {
                    t.preventDefault();
                    var e = $(this);
                    modalConfirmation.create(translate_javascripts["Are you sure to delete this?"], null, {
                        onContinue: function() {
                            e.parent().parent().parent().remove()
                        }
                    }).show()
                })
            }
        }
    }(),
    virtualProduct = function() {
        function a(t) {
            $.ajax({
                type: "GET",
                url: t.attr("href").replace(/\/\d+(?=\?.*)/, "/" + i),
                success: function() {
                    $("#form_step3_virtual_product_file_input").removeClass("hide").addClass("show"), $("#form_step3_virtual_product_file_details").removeClass("show").addClass("hide")
                }
            })
        }
        var i = $("#form_id_product").val();
        return {
            init: function() {
                $(document).on("change", 'input[name="form[step3][virtual_product][is_virtual_file]"]', function() {
                    var t;
                    "1" === $(this).val() ? $("#virtual_product_content").show() : ($("#virtual_product_content").hide(), t = $("#virtual_product").attr("data-action-remove").replace(/remove\/\d+/, "remove/" + i), $.ajax({
                        type: "GET",
                        url: t,
                        success: function() {
                            $("#form_step3_virtual_product_file_input").removeClass("hide").addClass("show"), $("#form_step3_virtual_product_file_details").removeClass("show").addClass("hide"), $("#form_step3_virtual_product_name").val(""), $("#form_step3_virtual_product_nb_downloadable").val(0), $("#form_step3_virtual_product_expiration_date").val(""), $("#form_step3_virtual_product_nb_days").val(0)
                        }
                    }))
                }), $("#form_step3_virtual_product_file").change(function(t) {
                    var e, a;
                    void 0 !== $(this)[0].files ? (e = $(this)[0].files, a = "", $.each(e, function(t, e) {
                        a += e.name + ", "
                    }), $("#form_step3_virtual_product_name").val(a.slice(0, -2))) : (a = $(this).val().split(/[\\/]/), $("#form_step3_virtual_product_name").val(a[a.length - 1]))
                }), "1" === $('input[name="form[step3][virtual_product][is_virtual_file]"]:checked').val() ? $("#virtual_product_content").show() : $("#virtual_product_content").hide(), $("#form_step3_virtual_product_file_details .delete").click(function(t) {
                    t.preventDefault();
                    var e = $(this);
                    modalConfirmation.create(translate_javascripts["Are you sure to delete this?"], null, {
                        onContinue: function() {
                            a(e)
                        }
                    }).show()
                }), $("#form_step3_virtual_product_save").click(function() {
                    var t = $(this),
                        e = new FormData;
                    $("#form_step3_virtual_product_file")[0].files[0] && e.append("product_virtual[file]", $("#form_step3_virtual_product_file")[0].files[0]), e.append("product_virtual[is_virtual_file]", $('input[name="form[step3][virtual_product][is_virtual_file]"]:checked').val()), e.append("product_virtual[name]", $("#form_step3_virtual_product_name").val()), e.append("product_virtual[nb_downloadable]", $("#form_step3_virtual_product_nb_downloadable").val()), e.append("product_virtual[expiration_date]", $("#form_step3_virtual_product_expiration_date").val()), e.append("product_virtual[nb_days]", $("#form_step3_virtual_product_nb_days").val()), $.ajax({
                        type: "POST",
                        url: $("#virtual_product").attr("data-action").replace(/save\/\d+/, "save/" + i),
                        data: e,
                        contentType: !1,
                        processData: !1,
                        beforeSend: function() {
                            t.prop("disabled", "disabled"), $("ul.text-danger").remove(), $("*.has-danger").removeClass("has-danger")
                        },
                        success: function(t) {
                            showSuccessMessage(translate_javascripts["Form update success"]), t.file_download_link && ($("#form_step3_virtual_product_file_details a.download").attr("href", t.file_download_link), $("#form_step3_virtual_product_file_input").removeClass("show").addClass("hide"), $("#form_step3_virtual_product_file_details").removeClass("hide").addClass("show"))
                        },
                        error: function(t) {
                            $.each(jQuery.parseJSON(t.responseText), function(t, e) {
                                var a = '<ul class="list-unstyled text-danger">';
                                $.each(e, function(t, e) {
                                    a += "<li>" + e + "</li>"
                                }), a += "</ul>", $("#form_step3_virtual_product_" + t).parent().append(a), $("#form_step3_virtual_product_" + t).parent().addClass("has-danger")
                            })
                        },
                        complete: function() {
                            t.removeAttr("disabled")
                        }
                    })
                })
            },
            destroy: function() {
                var t = "#form_step3_virtual_product_file_details",
                    t = (!$(t).hasClass("hide") && (t = $(t + " .delete"), a(t)), "#form_step3_virtual_product_is_virtual_file_");
                $(t + "0").prop("checked", !1), $(t + "1").prop("checked", !0), $("#virtual_product_content input").val("")
            }
        }
    }(),
    attachmentProduct = function() {
        var i = $("#form_id_product").val();
        return {
            init: function() {
                var e = $("#form_step6_attachment_product_add"),
                    t = $("#form_step6_attachment_product_cancel");

                function a() {
                    $("#form_step6_attachment_product_file").val(""), $("#form_step6_attachment_product_name").val(""), $("#form_step6_attachment_product_description").val("")
                }
                $("#product-attachment-files-check").change(function() {
                    $(this).is(":checked") ? $('#product-attachment-file input[type="checkbox"]').prop("checked", !0) : $('#product-attachment-file input[type="checkbox"]').prop("checked", !1)
                }), t.click(function() {
                    a()
                }), $("#form_step6_attachment_product_add").click(function() {
                    $(this);
                    var t = new FormData;
                    $("#form_step6_attachment_product_file")[0].files[0] && t.append("product_attachment[file]", $("#form_step6_attachment_product_file")[0].files[0]), t.append("product_attachment[name]", $("#form_step6_attachment_product_name").val()), t.append("product_attachment[description]", $("#form_step6_attachment_product_description").val()), $.ajax({
                        type: "POST",
                        url: $("#form_step6_attachment_product").attr("data-action").replace(/\/\d+(?=\?.*)/, "/" + i),
                        data: t,
                        contentType: !1,
                        processData: !1,
                        beforeSend: function() {
                            e.prop("disabled", "disabled"), $("ul.text-danger").remove(), $("*.has-danger").removeClass("has-danger")
                        },
                        success: function(t) {
                            a(), t.id && (t = '<tr>                <td class="col-md-3"><input type="checkbox" name="form[step6][attachments][]" value="' + t.id + '" checked="checked"> ' + t.real_name + '</td>                <td class="col-md-6">' + t.file_name + '</td>                <td class="col-md-2">' + t.mime + "</td>              </tr>", $("#product-attachment-file tbody").append(t), $(".js-options-no-attachments").addClass("hide"), $(".js-options-with-attachments").removeClass("hide"))
                        },
                        error: function(t) {
                            $.each(jQuery.parseJSON(t.responseText), function(t, e) {
                                var a = '<ul class="list-unstyled text-danger">';
                                $.each(e, function(t, e) {
                                    a += "<li>" + e + "</li>"
                                }), a += "</ul>", $("#form_step6_attachment_product_" + t).parent().append(a), $("#form_step6_attachment_product_" + t).parent().addClass("has-danger")
                            })
                        },
                        complete: function() {
                            e.removeAttr("disabled")
                        }
                    })
                })
            }
        }
    }(),
    imagesProduct = function() {
        var r = $("#product-images-dropzone"),
            a = $("#product-images-container .dropzone-expander");

        function o() {
            r.find(".dz-preview:not(.openfilemanager)").length ? r.find(".dz-preview.openfilemanager").show() : (r.removeClass("dz-started"), r.find(".dz-preview.openfilemanager").hide())
        }
        return {
            toggleExpand: function() {
                a.hasClass("expand") ? (r.css("height", "auto"), a.removeClass("expand").addClass("compress")) : (r.css("height", ""), a.removeClass("compress").addClass("expand"))
            },
            displayExpander: function() {
                a.show()
            },
            hideExpander: function() {
                a.hide()
            },
            shouldDisplayExpander: function() {
                var t = r.css("height"),
                    e = (r.css("height", ""), r.outerHeight()),
                    a = r[0].scrollHeight;
                return r.css("height", t), e < a
            },
            updateExpander: function() {
                this.shouldDisplayExpander() && this.displayExpander()
            },
            initExpander: function() {
                this.shouldDisplayExpander() && (this.displayExpander(), a.addClass("expand"));
                var t = this;
                $(document).on("click", "#product-images-container .dropzone-expander", function() {
                    t.toggleExpand()
                })
            },
            init: function() {
                Dropzone.autoDiscover = !1;
                var i = $("#product-images-dropzone-error"),
                    t = ($(document).on("click", "#product-images-dropzone .dz-preview", function() {
                        $(this).attr("data-id") && formImagesProduct.form($(this).attr("data-id"))
                    }), {
                        url: r.attr("url-upload"),
                        paramName: "form[file]",
                        maxFilesize: r.attr("data-max-size"),
                        addRemoveLinks: !0,
                        clickable: ".openfilemanager",
                        thumbnailWidth: 250,
                        thumbnailHeight: null,
                        acceptedFiles: "image/*",
                        dictRemoveFile: translate_javascripts.Delete,
                        dictFileTooBig: translate_javascripts.ToLargeFile,
                        dictCancelUpload: translate_javascripts.Delete,
                        sending: function(t, e) {
                            o(), a.addClass("expand").click(), i.html("")
                        },
                        queuecomplete: function() {
                            o(), r.sortable("enable"), imagesProduct.updateExpander()
                        },
                        processing: function() {
                            r.sortable("disable")
                        },
                        success: function(t, e) {
                            0 !== e.error ? (i.append("<p>" + t.name + ": " + e.error + "</p>"), this.removeFile(t)) : ($(t.previewElement).attr("data-id", e.id), $(t.previewElement).attr("url-update", e.url_update), $(t.previewElement).attr("url-delete", e.url_delete), $(t.previewElement).addClass("ui-sortable-handle"), 1 === e.cover && (imagesProduct.updateDisplayCover(e.id), rotator.updateDisplayRotator(e.id)))
                        },
                        error: function(t, e) {
                            var a = "";
                            "undefined" !== $.type(e) && ("string" === $.type(e) ? a = e : e.message && (a = e.message), "" !== a) && (i.append("<p>" + t.name + ": " + a + "</p>"), this.removeFile(t))
                        },
                        init: function() {
                            r.find(".dz-preview:not(.openfilemanager)").length ? r.addClass("dz-started") : r.find(".dz-preview.openfilemanager").hide(), r.sortable({
                                items: "div.dz-preview:not(.disabled)",
                                opacity: .9,
                                containment: "parent",
                                distance: 32,
                                tolerance: "pointer",
                                cursorAt: {
                                    left: 64,
                                    top: 64
                                },
                                cancel: ".disabled",
                                stop: function(t, e) {
                                    var a = {};
                                    $.each(r.find(".dz-preview:not(.disabled)"), function(t, e) {
                                        $(e).attr("data-id") ? a[$(e).attr("data-id")] = t + 1 : a = !1
                                    }), a && $.ajax({
                                        type: "POST",
                                        url: r.attr("url-position"),
                                        data: {
                                            json: JSON.stringify(a)
                                        }
                                    })
                                },
                                start: function(t, e) {
                                    r.find(".dz-preview").css("zIndex", 1), e.item.css("zIndex", 10)
                                }
                            }), r.disableSelection(), imagesProduct.initExpander()
                        }
                    });
                r.dropzone(jQuery.extend(t))
            },
            updateDisplayCover: function(t) {
                $("#product-images-dropzone .dz-preview .iscover").remove(), $('#product-images-dropzone .dz-preview[data-id="' + t + '"]').append('<div class="iscover">' + translate_javascripts.Cover + "</div>")
            },
            checkDropzoneMode: function() {
                o()
            },
            getOlderImageId: function() {
                return Math.min.apply(Math, $(".dz-preview").map(function() {
                    return $(this).data("id")
                }))
            }
        }
    }(),
    formImagesProduct = function() {
        var i = $("#product-images-dropzone"),
            a = $("#product-images-form-container");

        function e(t) {
            var e = "col-md-8",
                a = "col-md-12";
            !0 === t ? i.removeClass(e).addClass(a) : i.removeClass(a).addClass(e)
        }
        return a.magnificPopup({
            delegate: "a.open-image",
            type: "image"
        }), {
            form: function(t) {
                i.find(".dz-preview.active").removeClass("active"), i.find(".dz-preview[data-id='" + t + "']").addClass("active"), 0 == imagesProduct.shouldDisplayExpander() && i.css("height", "auto"), $.ajax({
                    url: i.find(".dz-preview[data-id='" + t + "']").attr("url-update"),
                    success: function(t) {
                        a.find("#product-images-form").html(t), form.switchLanguage($("#form_switch_language").val())
                    },
                    complete: function() {
                        e(!1), rotator.loaddataform(t), a.show(), rotator.test(t)
                    }
                })
            },
            send: function(t) {
                $.ajax({
                    type: "POST",
                    url: i.find(".dz-preview[data-id='" + t + "']").attr("url-update"),
                    data: a.find("textarea, input").serialize(),
                    beforeSend: function() {
                        a.find(".actions button").prop("disabled", "disabled"), a.find("ul.text-danger").remove(), a.find("*.has-danger").removeClass("has-danger")
                    },
                    success: function() {
                        a.find("#form_image_cover:checked").length && imagesProduct.updateDisplayCover(t)
                    },
                    error: function(t) {
                        t && t.responseText && $.each(jQuery.parseJSON(t.responseText), function(t, e) {
                            var a = '<ul class="list-unstyled text-danger">';
                            $.each(e, function(t, e) {
                                a += "<li>" + e + "</li>"
                            }), a += "</ul>", $("#form_image_" + t).parent().append(a), $("#form_image_" + t).parent().addClass("has-danger")
                        })
                    },
                    complete: function() {
                        a.find(".actions button").removeAttr("disabled")
                    }
                })
            },
            delete: function(e) {
                modalConfirmation.create(translate_javascripts["Are you sure to delete this?"], null, {
                    onContinue: function() {
                        $.ajax({
                            url: i.find('.dz-preview[data-id="' + e + '"]').attr("url-delete"),
                            complete: function() {
                                a.find(".close").click();
                                var t = !!i.find('.dz-preview[data-id="' + e + '"] .iscover').length;
                                i.find('.dz-preview[data-id="' + e + '"]').remove(), $(".images .product-combination-image [value=" + e + "]").parent().remove(), imagesProduct.checkDropzoneMode(), !0 == t && imagesProduct.updateDisplayCover(imagesProduct.getOlderImageId())
                            }
                        })
                    }
                }).show()
            },
            close: function() {
                e(!0), i.css("height", ""), a.find("#product-images-form").html(""), a.hide(), i.find(".dz-preview.active").removeClass("active")
            }
        }
    }(),
    rotator = function() {
        var formZoneElems = $("#product-images-form-container"),
            id_product = $("#form_id_product").val(),
            id_shop1 = $(".shop.active > a").attr("href"),
            id_shop = 0;
        return id_shop1 ? (matches = id_shop1.match(/\d+$/), matches && (id_shop = matches[0])) : id_shop = 0, {
            loaddataform: function(id) {
                $.ajax({
                    type: "POST",
                    url: "../../../../modules/posrotatorimg/ajax.php",
                    data: "id_product=" + id_product + "&action=2&shop_id=" + id_shop,
                    dataType: "json",
                    success: function(t) {
                        (data = JSON.parse(t)).id_image == id && $("#form_image_rotator").prop("checked", !0)
                    },
                    error: function(error) {
                        console.log(eval(error))
                    }
                })
            },
            getidrotator: function() {
                $.ajax({
                    type: "POST",
                    url: "../../../../modules/posrotatorimg/ajax.php",
                    data: "id_product=" + id_product + "&action=2&shop_id=" + id_shop,
                    dataType: "json",
                    success: function(t) {
                        data = JSON.parse(t), rotator.updateDisplayRotator(data.id_image)
                    }
                })
            },
            test: function(t) {
                formZoneElems.find("#form_image_rotator").on("click", function() {
                    var e;
                    e = $("#form_image_rotator").is(":checked") ? t : 0, $.ajax({
                        type: "POST",
                        url: "../../../../modules/posrotatorimg/ajax.php",
                        data: "img_id=" + e + "&id_product=" + id_product + "&action=1&shop_id=" + id_shop,
                        dataType: "json",
                        success: function(t) {
                            showSuccessMessage("Update successful"), rotator.updateDisplayRotator(e)
                        }
                    })
                })
            },
            updateDisplayRotator: function(t) {
                $("#product-images-dropzone .dz-preview .isRotator").remove(), $('#product-images-dropzone .dz-preview[data-id="' + t + '"]').append('<div class="iscover isRotator">Rotator</div>')
            }
        }
    }(),
    priceCalculation = function() {
        var e = $("#form_step2_price"),
            a = $("#form_step1_price_shortcut"),
            i = $("#form_step2_price_ttc"),
            r = $("#form_step1_price_ttc_shortcut"),
            o = $("#form_step2_ecotax"),
            n = $("#form_step2_id_tax_rules_group"),
            t = $("#step2_id_tax_rules_group_rendered"),
            c = e.attr("data-display-price-precision"),
            s = o.attr("data-eco-tax-rate");

        function d(t, e, a) {
            var i = t,
                r = 0;
            if ("0" === a)
                for (r in e) {
                    i *= 1 + parseFloat(e[r]) / 100;
                    break
                } else if ("1" === a) {
                    var o = 0;
                    for (r in e) o += e[r];
                    i *= 1 + parseFloat(o) / 100
                } else if ("2" === a)
                for (r in e) i *= 1 + parseFloat(e[r]) / 100;
            return i
        }

        function l(t, e, a) {
            var i = 0;
            if ("0" === a)
                for (i in e) {
                    t /= 1 + e[i] / 100;
                    break
                } else if ("1" === a) {
                    var r = 0;
                    for (i in e) r += e[i];
                    t /= 1 + r / 100
                } else if ("2" === a)
                for (i in e) t /= 1 + e[i] / 100;
            return t
        }

        function u() {
            var t = Tools.parseFloatFromString(o.val());
            return 0 === (t = isNaN(t) ? 0 : t) ? t : ps_round(t / (1 + s) * (1 + s), 6)
        }
        return {
            init: function() {
                n.change(function() {
                    t.val() !== n.val() && t.val(n.val()).trigger("change"), priceCalculation.taxInclude(), i.change()
                }), t.change(function() {
                    n.val(t.val()).trigger("change")
                }), $("#form_step1_price_shortcut, #form_step2_price").keyup(function() {
                    var t = priceCalculation.normalizePrice($(this).val());
                    ("form_step1_price_shortcut" === $(this).attr("id") ? $("#form_step2_price") : $("#form_step1_price_shortcut")).val(t).change(), priceCalculation.taxInclude()
                }), $("#form_step1_price_ttc_shortcut, #form_step2_price_ttc").keyup(function() {
                    var t = priceCalculation.normalizePrice($(this).val());
                    ("form_step1_price_ttc_shortcut" === $(this).attr("id") ? $("#form_step2_price_ttc") : $("#form_step1_price_ttc_shortcut")).val(t).change(), priceCalculation.taxExclude()
                }), $("#form_step2_price, #form_step2_price_ttc").change(function() {
                    var t = priceCalculation.normalizePrice($("#form_step2_price").val()),
                        e = priceCalculation.normalizePrice($("#form_step2_price_ttc").val());
                    formatCurrencyCldr(t, function(t) {
                        $("#final_retail_price_te").text(t)
                    }), formatCurrencyCldr(e, function(t) {
                        $("#final_retail_price_ti").text(t)
                    })
                }), $("#form_step2_ecotax").keyup(function() {
                    priceCalculation.taxExclude()
                }), $(document).on("keyup", ".combination-form .attribute_priceTE", function() {
                    priceCalculation.impactTaxInclude($(this)), priceCalculation.impactFinalPrice($(this))
                }), $(document).on("keyup", ".combination-form .attribute_priceTI", function() {
                    priceCalculation.impactTaxExclude($(this))
                }), $(document).on("blur", ".combination-form .attribute_wholesale_price,.combination-form .attribute_unity,.combination-form .attribute_priceTE", function() {
                    $(this).val(priceCalculation.normalizePrice($(this).val()))
                }), priceCalculation.taxInclude(), $("#form_step2_price, #form_step2_price_ttc").change()
            },
            normalizePrice: function(t) {
                return Tools.parseFloatFromString(t, !0)
            },
            addCurrentTax: function(t) {
                var e = this.getRates(),
                    a = n.find("option:selected").attr("data-computation-method");
                return Number(ps_round(d(t, e, a), c)) + Number(u())
            },
            taxInclude: function() {
                var t = truncateDecimals(this.addCurrentTax(this.normalizePrice(e.val())), 6);
                i.val(t).change(), r.val(t).change()
            },
            removeCurrentTax: function(t) {
                var e = this.getRates(),
                    a = n.find("option:selected").attr("data-computation-method");
                return ps_round(l(ps_round(t - u(), c), e, a), c)
            },
            taxExclude: function() {
                var t = truncateDecimals(this.removeCurrentTax(this.normalizePrice(i.val())), 6);
                e.val(t).change(), a.val(t).change()
            },
            impactTaxInclude: function(t) {
                var e, a, i = Tools.parseFloatFromString(t.val()),
                    t = t.closest('div[id^="combination_form_"]').find("input.attribute_priceTI"),
                    r = 0;
                isNaN(i) || (e = this.getRates(), a = n.find("option:selected").attr("data-computation-method"), r = ps_round(d(i, e, a), 6), r = truncateDecimals(r, 6)), t.val(r).trigger("change")
            },
            impactFinalPrice: function(t) {
                var e = this.normalizePrice(t.val()),
                    t = t.closest('div[id^="combination_form_"]').find(".final-price"),
                    a = t.attr("data-price"),
                    e = Number(e) + Number(a),
                    e = truncateDecimals(e, 6);
                t.html(e)
            },
            impactTaxExclude: function(t) {
                var e, a, i = Tools.parseFloatFromString(t.val()),
                    t = t.closest('div[id^="combination_form_"]').find("input.attribute_priceTE"),
                    r = 0;
                isNaN(i) || (e = this.getRates(), a = n.find("option:selected").attr("data-computation-method"), r = l(ps_round(i, c), e, a), r = truncateDecimals(r, 6)), t.val(r).trigger("change")
            },
            getRates: function() {
                return n.find("option:selected").attr("data-rates").split(",").map(function(t) {
                    return Tools.parseFloatFromString(t, !0)
                })
            }
        }
    }(),
    seo = function() {
        var t = $("#form_step5_redirect_type"),
            e = $("#id-product-redirected");

        function a() {
            "404" === t.val() ? $("#id-product-redirected").hide() : (i(), $("#id-product-redirected").show())
        }

        function i() {
            switch (t.val()) {
                case "301-category":
                case "302-category":
                    e.find("label").html(t.attr("data-labelcategory")), e.find("input").attr("placeholder", t.attr("data-placeholdercategory"));
                    break;
                default:
                    e.find("label").html(t.attr("data-labelproduct")), e.find("input").attr("placeholder", t.attr("data-placeholderproduct"))
            }
            e.find(".autocomplete-search").attr("data-remoteurl", t.find("option:selected").data("remoteurl")), e.find(".autocomplete-search").trigger("buildTypeahead")
        }

        function r(t) {
            var e = t.attr("name").match(/\d+/g)[1];
            $("#form_step5_link_rewrite_" + e).val(str2url(t.val(), "UTF-8"))
        }
        return {
            init: function() {
                a(), i(), t.change(function() {
                    e.find("#form_step5_id_type_redirected-data").html(""), a()
                }), $("#form_step1_names.friendly-url-force-update input").keyup(function() {
                    r($(this))
                }), $("#seo-url-regenerate").click(function() {
                    $.each($("#form_step1_names input"), function() {
                        r($(this))
                    })
                })
            },
            onSave: function() {
                $('input[id^="form_step5_link_rewrite_"]', "#form_step5_link_rewrite").each(function() {
                    var t = $(this);
                    0 === t.val().length && (t = t.attr("name").match(/\d+/g)[1], r($("#form_step1_name_" + t)))
                })
            }
        }
    }(),
    tags = {
        init: function() {
            $("#form_step6_tags .tokenfield").tokenfield({
                minWidth: "768px"
            })
        }
    },
    recommendedModules = {
        init: function() {
            this.moduleActionMenuLinkSelectors = "button.module_action_menu_install, button.module_action_menu_enable, button.module_action_menu_uninstall, button.module_action_menu_disable, button.module_action_menu_reset, button.module_action_menu_update", $(this.moduleActionMenuLinkSelectors).on("module_card_action_event", this.saveProduct)
        },
        saveProduct: function(t, e) {
            form.send()
        }
    };