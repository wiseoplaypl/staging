<link href="{$module_dir}views/css/admin_product.css" rel="stylesheet" type="text/css"/>
<div class="alert alert-info" role="alert">
    <p class="alert-text">{l s='Click on one image below to set it as the rotator image. The cover image is not showing on the list.' mod='posrotatorimg'}</p>
</div>
<div id="product-images-container-sthoverimage" class="m-b-2">
    <div  id="product-images-dropzone-sthoverimage"  class="panel dropzone ui-sortable col-md-12 dz-started" data-max-size="8">
        {foreach $images as $image}
        <div class="dz-preview dz-image-preview">
            <div id="rid{$image.id}" class="dz-image bg" data-id="{$image.id}" style="border: 1px solid #bbcdd2;background-size: cover;background-image: url('{$image.base_image_url}-home_default.{$image.format}');"></div>
            <div class="isRotator{if !$image['rotator']} hide{/if}" style=" background: #6c868e;
    font-size: 12px;
    color: #fff;
    text-align: center;
    padding: 5px;
    width: 100%;">{l s='Rotator' mod='posrotatorimg'}</div>
        </div>
        {/foreach}
    </div>
</div>
