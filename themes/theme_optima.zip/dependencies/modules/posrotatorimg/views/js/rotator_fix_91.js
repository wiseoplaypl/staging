$(document).ready(function() {

    $('#product-images-dropzone-sthoverimage .dz-image').click(function(){
  
          var module_url = posrotator_current_url;
          //alert(module_url)
        var _this = $(this);
        $.getJSON(module_url+'&ajax=1&action=update_hover&id_image='+_this.attr('id').replace('rid', ''), function(json){
            if (json.r) {
                $('#product-images-dropzone-sthoverimage').find('.isRotator').hide();
                
                if (_this.parent().find('.isRotator').hasClass('hide')) {
                    _this.parent().find('.isRotator').removeClass('hide').show(); 
                } else {
                    _this.parent().find('.isRotator').addClass('hide').hide();    
                }
                
            }
        });
    });
 })
